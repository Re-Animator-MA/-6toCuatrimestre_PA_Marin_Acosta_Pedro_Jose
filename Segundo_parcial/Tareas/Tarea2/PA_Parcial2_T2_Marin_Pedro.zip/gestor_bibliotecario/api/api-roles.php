<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre FROM roles WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                $rol = $resultado->fetch_assoc();
                http_response_code(200);
                echo json_encode([$rol], JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Rol no encontrado"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        }elseif (isset($_GET['todas']) && strtolower(trim($_GET['todas'])) === 'true') {
            $stmt = $conn->prepare("SELECT id, nombre FROM roles ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $roles = array();
            while ($row = $resultado->fetch_assoc()) {
                $roles[] = $row;
            }
            http_response_code(200);
            echo json_encode($roles, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        }elseif(isset($_GET['nombre'])){
            $nombre = trim($_GET['nombre']);
            $stmt = $conn -> prepare("SELECT id, nombre FROM roles WHERE nombre LIKE ?");
            $nombre_param = "%$nombre%";
            $stmt -> bind_param("s", $nombre_param);
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            $roles = array();
            if($resultado -> num_rows > 0){
                while($row = $resultado -> fetch_assoc()){
                    $roles[] = $row;
                }
                http_response_code(200);
                echo json_encode($roles, JSON_UNESCAPED_UNICODE);
            }else{
                http_response_code(404);
                echo json_encode(array("mensaje" => "No se encuetro el Rol"), JSON_UNESCAPED_UNICODE);
            }
            $stmt -> close();
            $conn -> close();
        } else {
            $stmt = $conn->prepare("SELECT id, nombre FROM roles ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $roles = array();
            while ($row = $resultado->fetch_assoc()) {
                $roles[] = $row;
            }
            http_response_code(200);
            echo json_encode($roles, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        }
        $conn->close();
        break;
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $nombre = trim($data['nombre'] ?? "");
        if(!empty($nombre)){
            $stmt = $conn -> prepare("INSERT INTO roles (nombre) VALUES (?)");
            $stmt -> bind_param("s", $nombre);
            if($stmt -> execute()){
                http_response_code(201);
                echo json_encode(array("mensaje" => "Rol Creado con exito"), JSON_UNESCAPED_UNICODE);
            }else{
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al crear el rol: ". $stmt -> error), JSON_UNESCAPED_UNICODE);
            }
        }else{
            http_response_code(400);
            echo json_encode(array("mensaje" => "El nombre es obligatorio"), JSON_UNESCAPED_UNICODE);
        }
        break;
    case 'PUT':
        if(isset($_GET['id'])){
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);
            $nombre = trim($data['nombre'] ?? '');
            if(!empty($nombre)){
                $stmt = $conn -> prepare("UPDATE roles SET nombre = ? WHERE id = ?");
                $stmt ->bind_param("si", $nombre, $id);
                if($stmt -> execute()){
                    http_response_code(200);
                    echo json_encode(array("mensaje" => "Rol actualizado con exito"), JSON_UNESCAPED_UNICODE);
                }else{
                    http_response_code(500);
                    echo json_encode(array("mensaje" => "Error al actualizar el rol: ". $stmt -> error), JSON_UNESCAPED_UNICODE);
                }
            }else{
                http_response_code(400);
                echo json_encode(array("mensaje" => "El nombre es obligatorio"), JSON_UNESCAPED_UNICODE);
            }
        }else{
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar un rol"), JSON_UNESCAPED_UNICODE);
        }
        break;
    case 'PATCH':
        if(isset($_GET['id'])){
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);
            $nombre = trim($data['nombre'] ?? "");
            if(!empty($nombre)){
                $stmt = $conn -> prepare("UPDATE roles SET nombre = COALESCE(NULLIF(?, ''), nombre) WHERE id = ?");
                $stmt -> bind_param("si", $nombre, $id);
                if($stmt -> execute()){
                    http_response_code(200);
                    echo json_encode(array("mensaje" => "Rol actualizado exitosamente"), JSON_UNESCAPED_UNICODE);
                }else{
                    http_response_code(500);
                    echo json_encode(array("mensaje" => "Error al actualizar el rol: ". $stmt -> error), JSON_UNESCAPED_UNICODE);
                }
            }else{
                http_response_code(400);
                echo json_encode(array("mensaje" => "Al menos un campo es obligatorio para actualizar el rol"), JSON_UNESCAPED_UNICODE);
            }
        }else{
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar un rol"), JSON_UNESCAPED_UNICODE);
        }
        break;
    case 'DELETE':
        if(isset($_GET['id'])){
            $id = intval($_GET['id']);
            $stmt = $conn -> prepare("DELETE FROM roles WHERE id = ?");
            $stmt -> bind_param("i", $id);
            if($stmt -> execute()){
                http_response_code(200);
                echo json_encode(array("mensaje" => "Rol eliminado exitosamente"), JSON_UNESCAPED_UNICODE);
            }else{
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al borrar el rol: ". $stmt -> error), JSON_UNESCAPED_UNICODE);
            }
        }else{
            http_response_code(400);
                echo json_encode(array("mensaje" => "El id es obligatorio para borrar el Rol"), JSON_UNESCAPED_UNICODE);
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
}
