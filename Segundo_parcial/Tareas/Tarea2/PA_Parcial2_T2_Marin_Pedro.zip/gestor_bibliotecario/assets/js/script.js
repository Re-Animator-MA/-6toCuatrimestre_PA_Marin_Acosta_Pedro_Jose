const URL_BASE = 'http://localhost/gestor_bibliotecario/api/';


// Funciones para realizar peticiones

//======================================================= CATEGORÍAS ===========================================
// GET ../api/api-categorias.php — listar todas
async function getCategorias() {
    const tbody = document.querySelector('#tabla-categorias tbody');
    if (!tbody) {
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-categorias.php`);
        const data = await response.json();
        tbody.innerHTML = '';
        data.forEach(categoria => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${categoria.id}</td>
                <td>${categoria.nombre}</td>
                <td>${categoria.descripcion}</td>
                <td>
                    <button class="btn btn-warning btn-sm" onclick="redirigirEditarCategoria(${categoria.id})">Editar</button>
                    <button class="btn btn-danger btn-sm" onclick="eliminarCategoria(${categoria.id})">Eliminar</button>
                </td>
            `;
            tbody.appendChild(tr);
        })
    } catch (error) {
        console.error('Error al obtener las categorías: ', error);
    }
}
// GET ../api/api-categorias.php?nombre=texto — buscar por nombre
async function buscarCategoriasPorNombre(nombre){
    const tbody = document.querySelector('#tabla-categorias tbody');
    if(!tbody) {
        return;
    }
    try{
        const response = await fetch(`${URL_BASE}api-categorias.php?nombre=${encodeURIComponent(nombre)}`);
        const data = await response.json();
        tbody.innerHTML = '';
        if (response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(categoria => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${categoria.id}</td>
                    <td>${categoria.nombre}</td>
                    <td>${categoria.descripcion}</td>
                    <td>
                        <button class="btn btn-warning btn-sm" onclick="redirigirEditarCategoria(${categoria.id})">Editar</button>
                        <button class="btn btn-danger btn-sm" onclick="eliminarCategoria(${categoria.id})">Eliminar</button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron categorías</td>
                </tr>
            `;
        }
    }catch(error){
        console.error('Error al buscar categorias: ', error);
        tbody.innerHTML = `
             <tr>
                <td colspan="4" style="text-align:center;color:#666;">Error al buscar categorías</td>
            </tr>
        `;
    }
}
// GET ../api/api-categorias.php?id=1 — obtener una por ID
async function getCategoriaPorId(id) {
    const tbody = document.querySelector('#tabla-categorias tbody');
    if(!tbody) {
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-categorias.php?id=${encodeURIComponent(id)}`);
        const data = await response.json();
        tbody.innerHTML = '';
        if (response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(categoria => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${categoria.id}</td>
                    <td>${categoria.nombre}</td>
                    <td>${categoria.descripcion}</td>
                    <td>
                        <button class="btn btn-warning btn-sm" onclick="redirigirEditarCategoria(${categoria.id})">Editar</button>
                        <button class="btn btn-danger btn-sm" onclick="eliminarCategoria(${categoria.id})">Eliminar</button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron categorías</td>
                </tr>
            `;
        }
    } catch (error) {
        console.error('Error al buscar categorias: ', error);
        tbody.innerHTML = `
             <tr>
                <td colspan="4" style="text-align:center;color:#666;">Error al buscar categorías</td>
            </tr>
        `;
    }
}

// POST ../api/api-categorias.php — crear (body: {nombre, descripcion})
async function crearCategoria(nombre, descripcion) {
    try {
        const nuevaCategoria = {
            nombre: nombre,
            descripcion: descripcion
        };
        const response = await fetch(`${URL_BASE}api-categorias.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(nuevaCategoria)
        })
        if (response.ok) {
            window.location.replace('index.php'); // Redirige a la página de listado de categorías después de crear una nueva
            return;
        } else {
            const errorData = await response.json().catch(() => null); // Intenta obtener el mensaje de error del cuerpo de la respuesta, si es que existe
            const mensaje = errorData?.mensaje || response.statusText || 'Error al crear la categoría';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al crear la categoría: ', error);
    }
}

// PUT ../api/api-categorias.php?id=1 — actualizar completa (body: {nombre, descripcion})
async function actualizarCategoria(id, nombre, descripcion) {
    const categoriaActualizada = {
        nombre: nombre,
        descripcion: descripcion
    }
    try {
        const response = await fetch(`${URL_BASE}api-categorias.php?id=${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(categoriaActualizada)
        })
        if (response.ok) {
            window.location.replace('index.php'); // Redirige a la página de listado de categorías después de actualizar
            return;
        } else {
            const errorData = await response.json().catch(() => null); // Intenta obtener el mensaje de error del cuerpo de la respuesta, si es que existe
            const mensaje = errorData?.mensaje || response.statusText || 'Error al actualizar la categoría';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al actualizar la categoría: ', error);
    }
}

// DELETE ../api/api-categorias.php?id=1 — eliminar
async function eliminarCategoria(id) {
    try {
        const response = await fetch(`${URL_BASE}api-categorias.php?id=${id}`, {
            method: 'DELETE'
        });
        if (response.ok) {
            window.location.replace('index.php'); // Redirige a la página de listado de categorías después de eliminar
            return;
        } else {
            const errorData = await response.json().catch(() => null); // Intenta obtener el mensaje de error del cuerpo de la respuesta, si es que existe
            const mensaje = errorData?.mensaje || response.statusText || 'Error al eliminar la categoría';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al eliminar la categoría: ', error);
    }
}

// Funciones generales para Categorias
async function eventoCrearCategoria() {
    const nombre = document.getElementById('nombre').value.trim(); // El método .value obtiene el valor del input con id 'nombre'
    const descripcion = document.getElementById('descripcion').value.trim(); // El método .value obtiene el valor del input con id 'descripcion'
    if (!nombre) {
        console.log('El nombre es obligatorio');
        return;
    }
    await crearCategoria(nombre, descripcion);
}

async function poblarFormularioEdicion(id) {
    const categoria = await getCategoriaPorId(id);
    if (categoria) {
        document.getElementById('nombre').value = categoria.nombre;
        document.getElementById('descripcion').value = categoria.descripcion;
    } else {
        console.log('No se pudo poblar el formulario de edición: categoría no encontrada');
    }
}

async function redirigirEditarCategoria(id) {
    // Redirige a la página de edición con el ID de la categoría como parámetro en la URL
    window.location.href = `edit.php?id=${id}`; // Redirige a la página de edición con el ID de la categoría como parámetro en la URL
}

// Función para obtener el ID de la categoría desde la URL
async function obtenerId() {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');
    if (id) {
        return id;
    } else {
        console.log('No se proporcionó un ID de categoría para editar');
        return null;
    }
}

//======================================================= ROLES ===========================================
//GET ../api/api-roles.php — listar todos
async function getRoles() {
    const tbody = document.querySelector('#tabla-roles tbody');
    if (!tbody) {
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-roles.php`);
        const data = await response.json();
        tbody.innerHTML = '';
        data.forEach(rol => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${rol.id}</td>
                <td>${rol.nombre}</td>
                <td>
                    <button class="btn btn-warning btn-sm" onclick="redirigirEditarRol(${rol.id})">Editar</button>
                    <button class="btn btn-danger btn-sm" onclick="eliminarRol(${rol.id})">Eliminar</button>
                </td>
            `;
            tbody.appendChild(tr);
        })
    } catch (error) {
        console.error('Error al obtener los roles: ', error);
    }
}
// GET ../api/api-roles.php?nombre=texto — buscar por nombre
async function buscarRolesPorNombre(nombre){
    const tbody = document.querySelector('#tabla-roles tbody');
    if(!tbody) {
        return;
    }
    try{
        const response = await fetch(`${URL_BASE}api-roles.php?nombre=${encodeURIComponent(nombre)}`);
        const data = await response.json();
        tbody.innerHTML = '';
        if (response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(rol => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${rol.id}</td>
                    <td>${rol.nombre}</td>
                    <td>
                        <button class="btn btn-warning btn-sm" onclick="redirigirEditarRol(${rol.id})">Editar</button>
                        <button class="btn btn-danger btn-sm" onclick="eliminarRol(${rol.id})">Eliminar</button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron roles</td>
                </tr>
            `;
        }
    }catch(error){
        console.error('Error al buscar roles: ', error);
        tbody.innerHTML = `
             <tr>
                <td colspan="4" style="text-align:center;color:#666;">Error al buscar roles</td>
            </tr>
        `;
    }
}
// GET ../api/api-roles.php?id=1 — obtener uno por ID
async function getRolPorId(id) {
    const tbody = document.querySelector('#tabla-roles tbody');
    if(!tbody) {
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-roles.php?id=${encodeURIComponent(id)}`);
        const data = await response.json();
        tbody.innerHTML = '';
        if (response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(rol => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${rol.id}</td>
                    <td>${rol.nombre}</td>
                    <td>
                        <button class="btn btn-warning btn-sm" onclick="redirigirEditarCategoria(${rol.id})">Editar</button>
                        <button class="btn btn-danger btn-sm" onclick="eliminarCategoria(${rol.id})">Eliminar</button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron roles</td>
                </tr>
            `;
        }
    } catch (error) {
        console.error('Error al buscar categorias: ', error);
        tbody.innerHTML = `
             <tr>
                <td colspan="4" style="text-align:center;color:#666;">Error al buscar roles</td>
            </tr>
        `;
    }
}
// POST ../api/api-roles.php — crear (body: {nombre})
async function crearRol(nombre) {
    try {
        const nuevoRol = {
            nombre: nombre
        };
        const response = await fetch(`${URL_BASE}api-roles.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(nuevoRol)
        })
        if (response.ok) {
            window.location.replace('index.php'); 
            return;
        } else {
            const errorData = await response.json().catch(() => null);
            const mensaje = errorData?.mensaje || response.statusText || 'Error al crear el rol';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al crear el rol: ', error);
    }
}

// PUT ../api/api-roles.php?id=1 — actualizar completa (body: {nombre})
async function actualizarRol(id, nombre) {
    const rolctualizado = {
        nombre: nombre
    }
    try {
        const response = await fetch(`${URL_BASE}api-roles.php?id=${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(rolActualizado)
        })
        if (response.ok) {
            window.location.replace('index.php'); 
            return;
        } else {
            const errorData = await response.json().catch(() => null); 
            const mensaje = errorData?.mensaje || response.statusText || 'Error al actualizar el rol';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al actualizar lel rol: ', error);
    }
}
// DELETE ../api/api-roles.php?id=1 — eliminar
async function eliminarRol(id) {
    try {
        const response = await fetch(`${URL_BASE}api-roles.php?id=${id}`, {
            method: 'DELETE'
        });
        if (response.ok) {
            window.location.replace('index.php'); 
            return;
        } else {
            const errorData = await response.json().catch(() => null); 
            const mensaje = errorData?.mensaje || response.statusText || 'Error al eliminar el rol';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al eliminar el rol: ', error);
    }
}
// Funciones generales para roles
async function eventoCrearRol() {
    const nombre = document.getElementById('nombre').value.trim(); 
    if (!nombre) {
        console.log('El nombre es obligatorio');
        return;
    }
    await crearRol(nombre);
}
async function poblarFormularioEdicionRol(id) {
    const rol = await getRolPorId(id);
    if (categoria) {
        document.getElementById('nombre').value = rol.nombre;
    } else {
        console.log('No se pudo poblar el formulario de edición: rol no encontrado');
    }
}
async function redirigirEditarRol(id) {
    window.location.href = `edit.php?id=${id}`; 
}
async function obtenerIdRol() {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');
    if (id) {
        return id;
    } else {
        console.log('No se proporcionó un ID de Rol para editar');
        return null;
    }
}

// Llamadas de funciones y eventos 
document.addEventListener('DOMContentLoaded', () => {
    getCategorias();
    // Se crea esta variable para almacenar el formulario de alta de categorías y se agrega un listener al evento submit del formulario. Así, cuando se envíe el formulario se manda a llamar a la función eventoCrearCategoria() que se encarga de obtener los valores de los inputs y llamar a la función crearCategoria() para enviar los datos al servidor.
    const categoriaCreateForm = document.getElementById('categoria-create-form');
    const categoriaEditForm = document.getElementById('categoria-edit-form');
    if (categoriaCreateForm) {
        categoriaCreateForm.addEventListener('submit', (event) => {
            event.preventDefault(); // Evita que el formulario se envíe de la manera tradicional
            eventoCrearCategoria();
        });
    }
    if (categoriaEditForm) {
        obtenerId().then((id) => { // Llama a la función obtenerId() para obtener el ID de la categoría desde la URL y luego llama a poblarFormularioEdicion(id) para llenar el formulario con los datos de la categoría correspondiente.
            if (id) {
                poblarFormularioEdicion(id);
            } else {
                console.log('No se proporcionó un ID de categoría para editar');
            }
        });
        categoriaEditForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const nombre = document.getElementById('nombre').value.trim();
            const descripcion = document.getElementById('descripcion').value.trim();
            obtenerId().then((id) => { // Llama a la función obtenerId() para obtener el ID de la categoría desde la URL y luego llama a actualizarCategoria(id, nombre, descripcion) para enviar los datos actualizados al servidor.
                if (id) {
                    actualizarCategoria(id, nombre, descripcion);
                } else {
                    console.log('No se proporcionó un ID de categoría para actualizar');
                }
            });
        });
    }
    const searchInput = document.getElementById('search-input');
    if(searchInput){
        searchInput.addEventListener('input', (event) => {
            const valor = event.target.value.trim();
            if(valor){
                buscarCategoriasPorNombre(valor);
                getCategoriaPorId(valor);
            }else{
                getCategorias();
            }
        });
    }
    // ======================= ROLES =======================
    getRoles();
    const rolCreateForm = document.getElementById('rol-create-form');
    const rolEditForm = document.getElementById('rol-edit-form');
    if (rolCreateForm) {
        rolCreateForm.addEventListener('submit', (event) => {
            event.preventDefault(); 
            eventoCrearRol();
        });
    }
    if (rolEditForm) {
        obtenerIdRol().then((id) => { // Llama a la función obtenerId() para obtener el ID de la categoría desde la URL y luego llama a poblarFormularioEdicion(id) para llenar el formulario con los datos de la categoría correspondiente.
            if (id) {
                poblarFormularioEdicionRol(id);
            } else {
                console.log('No se proporcionó un ID de rol para editar');
            }
        });
        rolEditForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const nombre = document.getElementById('nombre').value.trim();
            obtenerIdRol().then((id) => { 
                if (id) {
                    actualizarRol(id, nombre);
                } else {
                    console.log('No se proporcionó un ID de rol para actualizar');
                }
            });
        });
    }
    const searchInputRol = document.getElementById('search-input2');
    if(searchInputRol){
        searchInputRol.addEventListener('input', (event) => {
            const valor = event.target.value.trim();
            if(valor){
                getRolPorId(valor);
                buscarRolesPorNombre(valor);
            }else{
                getRoles();
            }
        });
    }
});
