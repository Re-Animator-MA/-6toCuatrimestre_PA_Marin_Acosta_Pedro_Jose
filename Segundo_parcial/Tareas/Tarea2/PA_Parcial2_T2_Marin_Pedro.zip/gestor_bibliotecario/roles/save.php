<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }

    $nombre = trim($_POST["nombre"] ?? "");

    if ($nombre === "") {
        header("Location: create.php?error=" . urlencode("El nombre del ro es obligatorio"));
        exit;
    } 

    // Aquí va el código para crear el autor usando una consulta preparada
    $stmt = $conn->prepare("INSERT INTO roles (nombre) VALUES (?)");
    $stmt->bind_param("s", $nombre);

    if ($stmt->execute()) {
        header("Location: index.php?success=" . urlencode("Rol creado exitosamente"));
        exit;
    } else {
        header("Location: create.php?error=" . urlencode("Error al crear el Rol: " . $stmt->error));
        exit;
    }
    $stmt->close();
    $conn->close();
?>
