<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }

    $id = intval($_POST['id']?? 0);
    $nombre = trim($_POST["nombre"] ?? "");

    if ( $id <= 0|| $nombre === "") {
        header("Location: create.php?error=" . urlencode("El nombre del ro es obligatorio"));
        exit;
    } 

    $stmt = $conn->prepare("UPDATE roles SET nombre = ? WHERE id = ?");
    $stmt->bind_param("si", $nombre, $id);

    if ($stmt->execute()) {
        header("Location: index.php?success=" . urlencode("Rol actualizado exitosamente"));
        exit;
    } else {
        header("Location: create.php?error=" . urlencode($id). "&error=" . urlencode("Error al actualizar el Rol: " . $stmt->error));
        exit;
    }
    $stmt->close();
    $conn->close();
?>
