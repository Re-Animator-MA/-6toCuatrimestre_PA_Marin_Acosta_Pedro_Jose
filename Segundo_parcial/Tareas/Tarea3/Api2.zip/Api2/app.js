const BASE_URL ="http://192.168.1.117/videojuegos_app/";
// GET----------------------------------------------------------------------------------
async function buscarVideojuegos(){
    const tbody = document.querySelector(`#resultados-1 tbody`);
    if(!tbody){return;}
    try{
        const response  = await fetch(`${BASE_URL}api-videojuego.php`);
        //console.log(await response.text());
        const data = await response.json();
        tbody.innerHTML='';
        if (response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(juego => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${juego.id}</td>
                    <td>${juego.titulo}</td>
                    <td>${juego.descripcion}</td>
                    <td> $${juego.precio}</td>
                    <td> ${juego.lanzamiento}</td>
                    <td ${juego.calificacion}</td>
                    <td> ${juego.imagen}</td>
                    <td> ${juego.id_genero}</td>
                    <td> ${juego.id_plataforma}</td>      
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron juegos</td>
                </tr>
            `;
        }
    }catch (error) {
        console.error('Error al buscar videojuegos: ', error);
        tbody.innerHTML = `
            <tr>
                <td style="text-align:center;color:#666;">Error al buscar videojuegos</td>
            </tr>
        `;
    }       
}
async function buscarJuegosPorNombre(nombre) {
    const tbody = document.querySelector('#resultados-1 tbody');
    if (!tbody) {return;}
    try {
        /*const url = nombre
            ? `${BASE_URL}api-videojuegos.php?nombre=${encodeURIComponent(nombre)}`
            : `${BASE_URL}api-videojuegos.php`;
        */
        const response = await fetch(`${BASE_URL}api-videojuego.php?nombre=${encodeURIComponent(nombre)}`);
        const data = await response.json();
        tbody.innerHTML = '';

        if(response.ok && data){
            const juegos = Array.isArray(data) ? data : [data];
            if(juegos.length > 0){
                juegos.forEach(juego => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${juego.id}</td>
                        <td>${juego.titulo}</td>
                        <td>${juego.descripcion}</td>
                        <td> $${juego.precio}</td>
                        <td> ${juego.lanzamiento}</td>
                        <td> ${juego.calificacion}</td>
                        <td> ${juego.imagen}</td>
                        <td> ${juego.id_genero}</td>
                        <td> ${juego.id_plataforma}</td>      
                    `;
                    tbody.appendChild(tr);
                });
            }
            
        }else{
            tbody.innerHTML = `
                 <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron juegos</td>
                </tr>
            `;
        }
    }catch (error) {
        console.error('Error al buscar videojuegos: ', error);
        tbody.innerHTML = `
            <tr>
                <td style="text-align:center;color:#666;">Error al buscar videojuegos</td>
            </tr>
        `;
    }       
}
async function buscarJuegosPorId(id = '') {
    const tbody = document.querySelector('#resultados-1 tbody');
    if (!tbody) {return;}
    try {
        /*const url = id
            ? `${BASE_URL}api-videojuegos.php?id=${encodeURIComponent(id)}`
            : `${BASE_URL}api-videojuegos.php`;
        */
        const response = await fetch(`${BASE_URL}api-videojuego.php?id=${encodeURIComponent(id)}`);
        const data = await response.json();
        tbody.innerHTML = '';

        if(response.ok && Array.isArray(data) && data.length > 0){
            //console.log("Respuesta JSON:", data);
            data.forEach(juego => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${juego.id}</td>
                    <td>${juego.titulo}</td>
                    <td>${juego.descripcion}</td>
                    <td> $${juego.precio}</td>
                    <td> ${juego.lanzamiento}</td>
                    <td> ${juego.calificacion}</td>
                    <td> ${juego.imagen}</td>
                    <td> ${juego.id_genero}</td>
                    <td> ${juego.id_plataforma}</td>      
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                 <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron juegos</td>
                </tr>
            `;
        }
    }catch (error) {
        console.error('Error al buscar videojuegos: ', error);
        tbody.innerHTML = `
            <tr>
                <td style="text-align:center;color:#666;">Error al buscar videojuegos</td>
            </tr>
        `;
    }       
}
async function buscarJuegosPorGenero(genero = '') {
    const tbody = document.querySelector('#resultados-1 tbody');
    if (!tbody) {return;}
    try {
        /*const url = id
            ? `${BASE_URL}api-videojuegos.php?id_genero=${encodeURIComponent(genero)}`
            : `${BASE_URL}api-videojuegos.php`;
        */
        const response = await fetch(`${BASE_URL}api-videojuego.php?id_genero=${encodeURIComponent(genero)}`);
        const data = await response.json();
        tbody.innerHTML = '';

        if(response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(juego => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${juego.id}</td>
                    <td>${juego.titulo}</td>
                    <td>${juego.descripcion}</td>
                    <td> $${juego.precio}</td>
                    <td> ${juego.lanzamiento}</td>
                    <td> ${juego.calificacion}</td>
                    <td> ${juego.imagen}</td>
                    <td> ${juego.id_genero}</td>
                    <td> ${juego.id_plataforma}</td>      
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                 <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron juegos</td>
                </tr>
            `;
        }
    }catch (error) {
        console.error('Error al buscar videojuegos: ', error);
        tbody.innerHTML = `
           <tr>
                <td style="text-align:center;color:#666;">Error al buscar videojuegos</td>
            </tr>
        `;
    }       
}
async function buscarJuegosPorPlataforma(plataforma = '') {
    const tbody = document.querySelector('#resultados-1 tbody');
    if (!tbody) {return;}
    try {
        /*const url = id
            ? `${BASE_URL}api-videojuegos.php?id_plataforma=${encodeURIComponent(plataforma)}`
            : `${BASE_URL}api-videojuegos.php`;
        */
        const response = await fetch(`${BASE_URL}api-videojuego.php?id_plataforma=${encodeURIComponent(plataforma)}`);
        const data = await response.json();
        tbody.innerHTML = '';

        if(response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(juego => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${juego.id}</td>
                    <td>${juego.titulo}</td>
                    <td>${juego.descripcion}</td>
                    <td> $${juego.precio}</td>
                    <td> ${juego.lanzamiento}</td>
                    <td> ${juego.calificacion}</td>
                    <td> ${juego.imagen}</td>
                    <td> ${juego.id_genero}</td>
                    <td> ${juego.id_plataforma}</td>      
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron juegos</td>
                </tr>
            `;
        }
    }catch (error) {
        console.error('Error al buscar videojuegos: ', error);
        tbody.innerHTML = `
            <tr>
                <td style="text-align:center;color:#666;">Error al buscar videojuegos</td>
            </tr>
        `;
    }       
}
async function buscarImagenDeJuegosPorNombre(nombre=''){
    const contenedor = document.querySelector('#resultados-2');
    if(!contenedor) {return;}
    try{
        const url = nombre
            ? `${BASE_URL}api-imagen.php?nombre=${encodeURIComponent(nombre)}`
            : `${BASE_URL}api-imagen.php`;

        const response = await fetch(url)  //(`${BASE_URL}api-imagen.php?nombre=${encodeURIComponent(nombre)}.jpg`);
        const data = await response.json();
        contenedor.innerHTML = '';
        
        if (response.ok && Array.isArray(data) && data.length > 0){
            contenedor.innerHTML = "<h3> Imagen </h3>";
            data.forEach(juego => {
                const img = document.createElement("img");
                img.src = juego.imagen;
                img.alt = juego.nombre;
                img.width = 150;
                img.classList.add("img-thumbnail", "m-2");
                
                const card = document.createElement("div")
                card.classList.add("card", "p-2", "mb-3");
                card.appendChild(img);

                contenedor.appendChild(card);
            });
        }else{
            contenedor.innerHTML = `
                <p style="text-align:center;color:#666;">No se encontraron imagenes</p>
            `;
        }
    }catch(error){
        console.error('Error al buscar imagenes: ', error);
        contenedor.innerHTML = `
            <p style="text-align:center;color:#666;">Error al buscar imagenes</p>
        `;
    }
}
//POST------------------------------------------------------------------------------------------


//clear table
function borrar_Tabala(){
    const tbody = document.querySelector('#resultados-1 tbody');
    if(tbody) tbody.innerHTML = '';
}

document.getElementById('btn-get-all').addEventListener("click", async() => {
    buscarVideojuegos();
});
document.getElementById('btn-get-one').addEventListener("click", async() => {
    const nombre = document.getElementById('search-input').value.trim();
    if(nombre){
        buscarImagenDeJuegosPorNombre();
    }
});
document.getElementById('btn-clear').addEventListener("click", () => {
    const tbody = document.querySelector('#resultados-1 tbody');
    //document.getElementById('resultados-1 tbody').innerHTML = '';
    //document.getElementById('resultados-2').innerHTML = '';
    if(tbody) tbody.innerHTML = '';
});
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('search-input');
    const searchInput2 = document.getElementById('search-input2');
    if(searchInput){
        searchInput.addEventListener('input', (event) => {
            const valor = event.target.value.trim();
            if(valor){
                buscarJuegosPorId(valor);
                buscarJuegosPorNombre(valor);
            }//else{
               borrar_Tabala();
            //}
        });
    }
    if(searchInput2){
        searchInput2.addEventListener('input', (event) => {
            const valor = event.target.value.trim();
            if(valor){
                buscarJuegosPorGenero(valor);
                buscarJuegosPorPlataforma(valor);
            }//else{
               borrar_Tabala();
            //}
        });
    }
});