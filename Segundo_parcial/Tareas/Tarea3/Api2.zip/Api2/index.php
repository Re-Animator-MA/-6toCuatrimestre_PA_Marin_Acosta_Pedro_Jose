<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fetch API</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body >
    <div class="" >
        <header>
            <h1>Videojuegos</h1>
            <p>Api ejemplos</p>
        </header>
        <main>
            <div style="display:flex;gap:12px;align-items:center">
                <select name="" id="search-type">
                    <option value="id">ID</option>
                    <option value="nombre">Nombre</option>
                    <option value="genero">Genero</option>
                    <option value="plataforma">Plataforma</option>
                    <option value="imagen">Imagen</option>
                </select>
                <input type="text" id="search-input" placeholder="Buscar id/nombre"
                style="padding:10px 14px;border:2px solid #e2e8f0;border-radius:8px;font-size:14px;width:260px">
            </div>
            <section class="card">
                <h2>Obtener posts</h2>
                <p>lee los recursos del servideor</p>
                <div class="controls">
                    <button id="btn-get-all">Obtener videojuegos</button>
                    <button id="btn-clear">Limpiar</button>
                    <button id="btn-get-one">Obtener imagen</button>
                </div>

                <div id="resultados-1">
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Tutulo</th>
                                <th>Descripción</th>
                                <th>Precio</th>
                                <th>Lanzamiento</th>
                                <th>Calificación</th>
                                <th>Imagen</th>
                                <th>Genero</th>
                                <th>Plataforma</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
                <div id="resultados-2"> </div>
            </section>
            <section class="card">
                <h2 style="color: #fff">Crear post</h2>
                <p>Crea un recurso </p>

                <label for="titulo">Titulo</label><br>
                <input type="text" id="titulo" style="padding:3px 14px;border:2px solid #e2e8f0;border-radius:8px;font-size:14px;width:260px"><br>

                <label for="descripcion">Descripción</label><br>
                <input type="text" id="descripcion" style="padding:3px 14px;border:2px solid #e2e8f0;border-radius:8px;font-size:14px;width:260px"><br>

                <label for="precio">Precio</label><br>
                <input type="number" id="precio" step="any" placeholder="$" style="padding:3px 14px;border:2px solid #e2e8f0;border-radius:8px;font-size:14px;width:260px"><br>

                <label for="lanzamiento">Lanzamiento</label><br>
                <input type="date" id="lanzamiento" style="padding:3px 14px;border:2px solid #e2e8f0;border-radius:8px;font-size:14px;width:260px"><br>

                <label for="calificacion">Calificación</label><br>
                <input type="number" id="calificacion" step="any" style="padding:3px 14px;border:2px solid #e2e8f0;border-radius:8px;font-size:14px;width:260px"><br>

                <label for="file">Imagen</label><br>
                <input type="file" id="file" accept="image/*" style="padding:3px 14px;border:2px solid #e2e8f0;border-radius:8px;font-size:14px;width:260px"><br>

                <label for="id_genero">ID del Genero</label><br>
                <input type="number" id="id_genero" style="padding:3px 14px;border:2px solid #e2e8f0;border-radius:8px;font-size:14px;width:260px"><br>

                <label for="id_plataforma">ID de la Plataforma</label><br>
                <input type="number" id="id_plataforma" style="padding:3px 14px;border:2px solid #e2e8f0;border-radius:8px;font-size:14px;width:260px"><br>

            </section>
        </main>
        
    </div>
   <script src="app.js">
    
    </script>
</body>
</html>