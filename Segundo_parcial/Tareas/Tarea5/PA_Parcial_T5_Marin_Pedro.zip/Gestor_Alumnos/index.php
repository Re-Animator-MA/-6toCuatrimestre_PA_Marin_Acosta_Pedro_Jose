<?php include_once "includes/header.php";?>
<?php include_once "includes/consultas_sql.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
</div>
<div class="table-container" style="padding: 24px; margin-bottom: 24px;">
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px;">
        <div class="card" style="padding: 18px; max-width: 100%;">
            <h2 style="font-size: 16px; margin-bottom: 10px;"><i class="fas fa-tags"></i> Alumnos</h2>
            <p style="font-size: 28px; font-weight: 700;"><?= htmlspecialchars((string) $totales["alumnos"]) ?></p>
        </div>

        <div class="card" style="padding: 18px; max-width: 100%;">
            <h2 style="font-size: 16px; margin-bottom: 10px;"><i class="fas fa-users"></i> Alumnos Activos</h2>
            <p style="font-size: 28px; font-weight: 700;"><?= htmlspecialchars((string) $totales["alumnos_activos"]) ?></p>
        </div>

        <div class="card" style="padding: 18px; max-width: 100%;">
            <h2 style="font-size: 16px; margin-bottom: 10px;"><i class="fas fa-user"></i> Carreras</h2>
            <p style="font-size: 28px; font-weight: 700;"><?= htmlspecialchars((string) $totales["carreras"]) ?></p>
        </div>
        <div class="card" style="padding: 18px; max-width: 100%;">
            <h2 style="font-size: 16px; margin-bottom: 10px;"><i class="fas fa-book"></i> Cuatrimestres</h2>
            <p style="font-size: 28px; font-weight: 700;"><?= htmlspecialchars((string) $totales["cuatrimestres"]) ?></p>
        </div>
        
        <div class="card" style="padding: 18px; max-width: 100%;">
            <h2 style="font-size: 16px; margin-bottom: 10px;"><i class="fas fa-book"></i> Inscripciones</h2>
            <p style="font-size: 28px; font-weight: 700;"><?= htmlspecialchars((string) $totales["inscripciones"]) ?></p>
        </div>

        <div class="card" style="padding: 18px; max-width: 100%;">
            <h2 style="font-size: 16px; margin-bottom: 10px;"><i class="fas fa-book"></i> Materias</h2>
            <p style="font-size: 28px; font-weight: 700;"><?= htmlspecialchars((string) $totales["materias"]) ?></p>
        </div>
    </div>
</div>
<div class="page-header" style="margin-top: 8px;">
    <h1 style="font-size: 22px;"><i class="fas fa-clock"></i> Últimos Préstamos</h1>
</div>
<div class="table-container">
     <table style="font-size:small;">
        <thead>
            <tr>
                <th>Matricula</th>
                <th>Alumno</th>
                <th>Cuatrimestre</th>
                <th>Carreras</th>
                <th>Materias</th>
                <th>Creditos</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($alumnado)): ?>
                <tr>
                    <td colspan="5" class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <p>No hay alumnos registrados todavía.</p>
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($alumnado as $alumno): ?>
                    <tr>
                        <td><?= htmlspecialchars($alumno["matricula"]) ?></td>
                        <td><?= htmlspecialchars($alumno["nombre"] . " " . $alumno["apellido_paterno"] ." ". $alumno["apellido_materno"]) ?></td>
                        <td><?= htmlspecialchars($alumno["cuatrimestre_actual"]) ?></td>
                        <td><?= htmlspecialchars($alumno["carrera"]) ?></td>
                        <td><?= htmlspecialchars($alumno["materia"]) ?></td>
                        <td><?= htmlspecialchars($alumno["creditos"]) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php include_once "includes/footer.php";