<!DOCTYPE html>
<html lang="es">
<head>
    <base href="/gestor_alumnos/">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestor de Alumnos</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>
    <aside class="sidebar">
        <div class="sidebar-header">
            <h2><i class="fas fa-user-graduate"></i> Gestor</h2>
            <p>Gestión de alumnos</p>
        </div>
        <nav class="sidebar-nav">
            <a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="views/alumnos.php"><i class="fas fa-users"></i> Visualizar Alumnos</a>
            <a href="views/carreras.php"><i class="fas fa-search"></i> Carreras</a>
            <a href="views/cuatrimestres.php"><i class="fas fa-calendar"></i> Cuatrimestres</a>
            <a href="views/materias.php"><i class="fas fa-list"></i> Materias</a>
            <a href="views/inscripciones.php"><i class="fas fa-user-plus"></i> Inscripciones</a>
        </nav>
    </aside>
    <div class="main-content">
