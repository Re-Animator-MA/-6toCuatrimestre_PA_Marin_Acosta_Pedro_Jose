<?php
require_once "config/conexion.php";

$totales = [
        "alumnos" => 0,
        "alumnos_activos" => 0,
        "carreras" => 0,
        "cuatrimestres" => 0,
        "inscripciones" => 0,
        "materias" => 0,
    ];

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM alumnos");
    $stmt->execute();
    $resultado = $stmt->get_result();
    $totales["alumnos"] = (int) ($resultado->fetch_assoc()["total"] ?? 0);
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM alumnos WHERE estatus = 'Activo'");
    $stmt->execute();
    $resultado = $stmt->get_result();
    $totales["alumnos_activos"] = (int) ($resultado->fetch_assoc()["total"] ?? 0);
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM carreras");
    $stmt->execute();
    $resultado = $stmt->get_result();
    $totales["carreras"] = (int) ($resultado->fetch_assoc()["total"] ?? 0);
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM cuatrimestres");
    $stmt->execute();
    $resultado = $stmt->get_result();
    $totales["cuatrimestres"] = (int) ($resultado->fetch_assoc()["total"] ?? 0);
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM inscripciones");
    $stmt->execute();
    $resultado = $stmt->get_result();
    $totales["inscripciones"] = (int) ($resultado->fetch_assoc()["total"] ?? 0);
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM materias");
    $stmt->execute();
    $resultado = $stmt->get_result();
    $totales["materias"] = (int) ($resultado->fetch_assoc()["total"] ?? 0);
    $stmt->close();

    $alumnado = [];
    $stmt = $conn->prepare("SELECT 
    alumnos.matricula, 
    alumnos.nombre, alumnos.apellido_paterno, alumnos.apellido_materno, 
    alumnos.cuatrimestre_actual,
    carreras.nombre AS carrera,
    GROUP_CONCAT(materias.nombre SEPARATOR ' |--| ') AS materia,
    GROUP_CONCAT(materias.creditos SEPARATOR ' |--| ') AS creditos 
    FROM alumnos 
    INNER JOIN carreras ON alumnos.id_carrera = carreras.id 
    INNER JOIN materias ON materias.id_carrera = carreras.id
    GROUP BY alumnos.matricula, alumnos.nombre, alumnos.cuatrimestre_actual, carrera
    ORDER BY carrera, alumnos.apellido_paterno, alumnos.apellido_materno");
    $stmt->execute();
    $resultado = $stmt->get_result();
    while ($row = $resultado->fetch_assoc()) {
        $alumnado[] = $row;
    }
    $stmt->close();
    $conn->close();