    <br>
    <footer class="footer">
        <div class="footer-content">
            <<p>&copy; <?= date("Y") ?> Gestor Alumnos &mdash; Sistema de administración de Alumnos</p>
            <p><i class="fas fa-envelope"></i> contacto@instituto.edu.mx</p>
            <p>Versión 1.0.0 | Última actualización: Julio 2026</p>
        </div>
    </footer>
    </div>
    <?php
        $scriptFile = __DIR__ . '../assets/js/url.js';
        $scriptVersion = file_exists($scriptFile) ? filemtime($scriptFile) : time();
    ?>
    <?php
        $scriptFile = __DIR__ . '../assets/js/alumno-scripts.js';
        $scriptVersion = file_exists($scriptFile) ? filemtime($scriptFile) : time();
    ?>
    <?php 
        $scriptFile = __DIR__ . '../assets/js/carreras-scripts.js';
        $scriptVersion = file_exists($scriptFile) ? filemtime($scriptFile) : time();
    ?>
    <?php 
        $scriptFile = __DIR__ . '../assets/js/cuatrimestres-scripts.js';
        $scriptVersion = file_exists($scriptFile) ? filemtime($scriptFile) : time();
    ?>
    <?php 
        $scriptFile = __DIR__ . '../assets/js/materias-scripts.js';
        $scriptVersion = file_exists($scriptFile) ? filemtime($scriptFile) : time();
    ?>
    <?php 
        $scriptFile = __DIR__ . '../assets/js/inscripciones-scripts.js';
        $scriptVersion = file_exists($scriptFile) ? filemtime($scriptFile) : time();
    ?>
    <script src="<?= htmlspecialchars($basePath ?? '') ?>assets/js/url.js?v=<?= $scriptVersion ?>"></script>
    <script src="<?= htmlspecialchars($basePath ?? '') ?>assets/js/alumno-scripts.js?v=<?= $scriptVersion ?>"></script>
    <script src="<?= htmlspecialchars($basePath ?? '') ?>assets/js/carreras-scripts.js?v=<?= $scriptVersion ?>"></script>
    <script src="<?= htmlspecialchars($basePath ?? '') ?>assets/js/cuatrimestres-scripts.js?v=<?= $scriptVersion ?>"></script>
    <script src="<?= htmlspecialchars($basePath ?? '') ?>assets/js/materias-scripts.js?v=<?= $scriptVersion ?>"></script>
    <script src="<?= htmlspecialchars($basePath ?? '') ?>assets/js/inscripciones-scripts.js?v=<?= $scriptVersion ?>"></script>
</body>
</html>
