<?php include_once "../../includes/header.php";?>

<div class="page-header">
    <h1><i class="fas fa-plus-circle"></i> Nuevo Alumno</h1>
    <a href="views/alumnos.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<div id="alert-container"></div>

<div class="card">
    <form id="alumno-create-form">
        <div class="form-group">
            <label><i class="fas fa-tag"></i> Matricula </label><br>
            <input type="text" id="matricula" name="matricula">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-user"></i> Nombre </label><br>
            <input type="text" id="nombre" name="nombre">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-user"></i> Apellido Paterno </label><br>
            <input type="text" id="apellido_paterno" name="apellido_paterno">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-user"></i> Apellido Materno </label><br>
            <input type="text" id="apellido_materno" name="apellido_materno">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-envelope"></i> Correo </label><br>
            <input type="text" id="correo" name="correo">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-phone"></i> Telefono </label><br>
            <input type="text" id="telefono" name="telefono">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-calendar"></i> Fecha de Nacimiento </label><br>
            <input type="datetime-local" id="fecha_nacimiento" name="fecha_nacimiento">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-align-left"></i> Id Carrera </label><br>
            <input type="text" id="id_carrera" name="id_carrera">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-align-left"></i> Cuatrimestre Actual </label><br>
            <input type="text" id="cuatrimestre_actual" name="cuatrimestre_actual">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-tag"></i> Estatus </label><br>
            <input type="text" id="estatus" name="estatus">
        </div>
        <br>
        <div class="form-actions">
            <button type="submit" class="btn btn-success" id="guardar-alumno-btn">
                <i class="fas fa-save"></i> Guardar
            </button>
            <a href="views/alumnos.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>
<?php include_once "../../includes/footer.php";