<?php include_once "../includes/header.php";?>

<div class="page-header">
    <h1><i class="fas fa-users"></i> Alumnos</h1>
    <div style="display:flex;gap:12px;align-items:center">
        <input type="text" id="search-input-materias" placeholder="Buscar Materia..."
            style="padding:10px 14px;border:2px solid #e2e8f0;border-radius:8px;font-size:14px;width:260px">
    </div>
</div>

<div id="alert-container"></div>

<div class="table-container" id="tabla-materias">
    <table style="font-size:small;">
        <thead>
            <tr>
                <th>#</th>
                <th>Materia</th>
                <th>Creditos</th>
                <th>carrera</th>
                <th>Cuatrimestre</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
<?php include_once "../includes/footer.php";