<?php include_once "../includes/header.php";?>

<div class="page-header">
    <h1><i class="fas fa-tags"></i> Carreras</h1>
</div>
<div id="alert-container"></div>

<div class="table-container" id="tabla-cuatrimestre">
    <table style="font-size:small;">
        <thead>
            <tr>
                <th>#</th>
                <th>Nombre</th>
            </tr>
        </thead>
        <tbody>
            
        </tbody>
    </table>
</div>
<?php include_once "../includes/footer.php";