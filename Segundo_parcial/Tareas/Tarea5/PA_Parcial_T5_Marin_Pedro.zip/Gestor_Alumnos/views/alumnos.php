<?php include_once "../includes/header.php";?>

<div class="page-header">
    <h1><i class="fas fa-users"></i> Alumnos</h1>
    <div style="display:flex;gap:12px;align-items:center">
        <input type="text" id="search-input" placeholder="Buscar Alumno..."
            style="padding:10px 14px;border:2px solid #e2e8f0;border-radius:8px;font-size:14px;width:260px">
        <a href="views/actions-alumnos/create-alumno.php" class="btn btn-primary">
            <i class="fas fa-plus"></i> Nuevo Alumno
        </a>
    </div>
</div>

<div id="alert-container"></div>

<div class="table-container" id="tabla-alumnos">
    <table style="font-size:small;">
        <thead>
            <tr>
                <th>#</th>
                <th>Matricula</th>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Telefono</th>
                <th>Fecha de Nacimiento</th>
                <th>carrera</th>
                <th>Cuatrimiestre actual</th>
                <th>Estatus</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
<?php include_once "../includes/footer.php";