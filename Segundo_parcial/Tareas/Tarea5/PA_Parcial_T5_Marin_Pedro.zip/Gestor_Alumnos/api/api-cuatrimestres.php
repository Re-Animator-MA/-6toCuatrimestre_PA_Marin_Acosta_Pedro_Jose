<?php 
require_once "../config/conexion.php";

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
    $conn->close();
    exit;
}
switch ($method){
    case 'GET':
        if (isset($_GET['todas']) && strtolower(trim($_GET['todas'])) === 'true') {
            $stmt = $conn->prepare("SELECT id, nombre FROM cuatrimestres ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $cuatrimestres = array();
            while ($row = $resultado->fetch_assoc()) {
                $cuatrimestres[] = $row;
            }
            http_response_code(200);
            echo json_encode($cuatrimestres, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        } else {
            $stmt = $conn->prepare("SELECT id, nombre FROM cuatrimestres ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $cuatrimestres = array();
            while ($row = $resultado->fetch_assoc()) {
                $cuatrimestres[] = $row;
            }
            http_response_code(200);
            echo json_encode($cuatrimestres, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        };
        break;
        default:
            http_response_code(405);
            echo json_encode(array("mensaje" => "Método no permitido"), JSON_UNESCAPED_UNICODE);
        break;
}