<?php 
require_once "../config/conexion.php";

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT 
                alumnos.id AS id,
                alumnos.matricula AS matricula,
                alumnos.nombre AS nombre, 
                alumnos.apellido_paterno,
                alumnos.apellido_materno,
                alumnos.correo AS correo,
                alumnos.telefono AS telefono,
                alumnos.fecha_nacimiento AS fecha_nacimiento,
                carreras.nombre AS carrera, 
                alumnos.cuatrimestre_actual AS cuatrimestre_actual, 
                alumnos.estatus AS estatus 
                FROM alumnos INNER JOIN carreras ON alumnos.id_carrera= carreras.id 
                WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                $alumno = $resultado->fetch_assoc();
                http_response_code(200);
                echo json_encode([$alumno], JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "alumno no encontrado"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        } elseif (isset($_GET['todas']) && strtolower(trim($_GET['todas'])) === 'true') {
            $stmt = $conn->prepare("SELECT 
                alumnos.id AS id,
                alumnos.matricula AS matricula,
                alumnos.nombre AS nombre, 
                alumnos.apellido_paterno,
                alumnos.apellido_materno,
                alumnos.correo AS correo,
                alumnos.telefono AS telefono,
                alumnos.fecha_nacimiento AS fecha_nacimiento,
                carreras.nombre AS carrera, 
                alumnos.cuatrimestre_actual AS cuatrimestre_actual, 
                alumnos.estatus AS estatus 
                FROM alumnos INNER JOIN carreras ON alumnos.id_carrera= carreras.id ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $alumnos = array();
            while ($row = $resultado->fetch_assoc()) {
                $alumnos[] = $row;
            }
            http_response_code(200);
            echo json_encode($alumnos, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        } elseif (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $stmt = $conn->prepare("SELECT 
                alumnos.id AS id,
                alumnos.matricula AS matricula,
                alumnos.nombre AS nombre, 
                alumnos.apellido_paterno,
                alumnos.apellido_materno,
                alumnos.correo AS correo,
                alumnos.telefono AS telefono,
                alumnos.fecha_nacimiento AS fecha_nacimiento,
                carreras.nombre AS carrera, 
                alumnos.cuatrimestre_actual AS cuatrimestre_actual, 
                alumnos.estatus AS estatus 
                FROM alumnos INNER JOIN carreras ON alumnos.id_carrera= carreras.id WHERE nombre LIKE ?");
            $nombre_param = "%$nombre%";
            $stmt->bind_param("s", $nombre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $alumnos = array();
            if ($resultado->num_rows > 0) {
                while ($row = $resultado->fetch_assoc()) {
                    $alumnos[] = $row;
                }
                http_response_code(200);
                echo json_encode($alumnos, JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Alumno no encontrado"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        }elseif(isset($_GET['matricula'])){
            $matricula = trim($_GET['matricula']);
            $stmt = $conn->prepare("SELECT 
                alumnos.id AS id,
                alumnos.matricula AS matricula,
                alumnos.nombre AS nombre, 
                alumnos.apellido_paterno,
                alumnos.apellido_materno,
                alumnos.correo AS correo,
                alumnos.telefono AS telefono,
                alumnos.fecha_nacimiento AS fecha_nacimiento,
                carreras.nombre AS carrera, 
                alumnos.cuatrimestre_actual AS cuatrimestre_actual, 
                alumnos.estatus AS estatus 
                FROM alumnos INNER JOIN carreras ON alumnos.id_carrera= carreras.id WHERE matricula LIKE ?");
            $matricula_param = "%$matricula%";
            $stmt->bind_param("s", $matricula_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $alumnos = array();
            if ($resultado->num_rows > 0) {
                while ($row = $resultado->fetch_assoc()) {
                    $alumnos[] = $row;
                }
                http_response_code(200);
                echo json_encode($alumnos, JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Alumno no encontrado"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        } else {
            $stmt = $conn->prepare("SELECT 
                alumnos.id AS id,
                alumnos.matricula AS matricula,
                alumnos.nombre AS nombre, 
                alumnos.apellido_paterno,
                alumnos.apellido_materno,
                alumnos.correo AS correo,
                alumnos.telefono AS telefono,
                alumnos.fecha_nacimiento AS fecha_nacimiento,
                carreras.nombre AS carrera, 
                alumnos.cuatrimestre_actual AS cuatrimestre_actual, 
                alumnos.estatus AS estatus 
                FROM alumnos INNER JOIN carreras ON alumnos.id_carrera= carreras.id ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $alumnos = array();
            while ($row = $resultado->fetch_assoc()) {
                $alumnos[] = $row;
            }
            http_response_code(200);
            echo json_encode($alumnos, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        }
        //$conn -> close();
        break;
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $matricula = trim($data['matricula'] ?? "");
        $nombre = trim($data['nombre'] ?? "");
        $apellido_paterno = trim($data['apellido_paterno'] ?? "");
        $apellido_materno = trim($data['apellido_materno'] ?? "");
        $correo = trim($data['correo'] ?? "");
        $telefono = trim($data['telefono'] ?? "");
        $fecha_nacimiento = trim($data['fecha_nacimiento'] ?? "");
        $id_carrera = intval($data['id_carrera'] ?? 0);
        $cuatrimestre_actual = trim($data['cuatrimestre_actual'] ?? "");
        $estatus = trim($data['estatus'] ?? "");
        if (!empty($nombre) && !empty($apellido_paterno) && !empty($apellido_materno)) {
            $stmt = $conn->prepare("INSERT INTO alumnos 
            (matricula, 
            nombre,
            apellido_paterno,
            apellido_materno,
            correo,
            telefono,
            fecha_nacimiento,
            id_carrera,
            cuatrimestre_actual,
            estatus) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param(
                "sssssssiis", 
                $matricula, 
                $nombre, 
                $apellido_paterno,
                $apellido_materno,
                $correo,
                $telefono,
                $fecha_nacimiento,
                $id_carrera,
                $cuatrimestre_actual,
                $estatus);
            if ($stmt->execute()) {
                http_response_code(201);
                echo json_encode(array("mensaje" => "Alumno añadido exitosamente"), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al añadir al alumno: " . $stmt->error), JSON_UNESCAPED_UNICODE);
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El nombre completo es obligatorio"), JSON_UNESCAPED_UNICODE);
        }
        break;
    case 'PUT':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);
            $matricula = trim($data['matricula'] ?? "");
            $nombre = trim($data['nombre'] ?? "");
            $apellido_paterno = trim($data['apellido_paterno'] ?? "");
            $apellido_materno = trim($data['apellido_materno'] ?? "");
            $correo = trim($data['correo'] ?? "");
            $telefono = trim($data['telefono'] ?? "");
            $fecha_nacimiento = trim($data['fecha_nacimiento'] ?? "");
            $id_carrera = intval($data['id_carrera'] ?? 0);
            $cuatrimestre_actual = trim($data['cuatrimestre_actual'] ?? "");
            $estatus = trim($data['estatus'] ?? "");
            if (!empty($nombre) && !empty($apellido_paterno) && !empty($apellido_materno)) {
                    $stmt = $conn->prepare("UPDATE alumnos SET 
                    matricula = ?, 
                    nombre = ?, 
                    apellido_paterno = ?,
                    apellido_materno = ?,
                    correo = ?,
                    telefono = ?,
                    fecha_nacimiento = ?,
                    id_carrera = ?,
                    cuatrimestre_actual = ?,
                    estatus = ?
                    WHERE id = ?");
                $stmt->bind_param(
                    "sssssssiis", 
                    $matricula, 
                    $nombre, 
                    $apellido_paterno,
                    $apellido_materno,
                    $correo,
                    $telefono,
                    $fecha_nacimiento,
                    $id_carrera,
                    $cuatrimestre_actual,
                    $estatus);
                if ($stmt->execute()) {
                    http_response_code(200);
                    echo json_encode(array("mensaje" => "Alumno actualizado exitosamente"), JSON_UNESCAPED_UNICODE);
                } else {
                    http_response_code(500);
                    echo json_encode(array("mensaje" => "Error al actualizar Alumno: " . $stmt->error), JSON_UNESCAPED_UNICODE);
                }
            } else {
                http_response_code(400);
                echo json_encode(array("mensaje" => "El nombre completo es obligatorio"), JSON_UNESCAPED_UNICODE);
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar a un alumno"), JSON_UNESCAPED_UNICODE);
        }
        break;
    case 'PATCH':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);
            $matricula = trim($data['matricula'] ?? "");
            $nombre = trim($data['nombre'] ?? "");
            $apellido_paterno = trim($data['apellido_paterno'] ?? "");
            $apellido_materno = trim($data['apellido_materno'] ?? "");
            $correo = trim($data['correo'] ?? "");
            $telefono = trim($data['telefono'] ?? "");
            $fecha_nacimiento = trim($data['fecha_nacimiento'] ?? "");
            $id_carrera = intval($data['id_carrera'] ?? 0);
            $cuatrimestre_actual = trim($data['cuatrimestre_actual'] ?? "");
            $estatus = trim($data['estatus'] ?? "");
            if (!empty($nombre) || !empty($apellido_paterno) || !empty($apellido_materno)) {
                $stmt = $conn->prepare("UPDATE categorias SET 
                matricula = COALESCE(NULLIF(?, ''), matricula),
                nombre = COALESCE(NULLIF(?, ''), nombre), 
                apellido_paterno = COALESCE(NULLIF(?, ''), apellido_paterno),
                apellido_materno = COALESCE(NULLIF(?, ''), apellido_materno),
                correo = COALESCE(NULLIF(?, ''), correo),
                telefono = COALESCE(NULLIF(?, ''), telefono),
                fecha_nacimiento = COALESCE(NULLIF(?, ''), fecha_nacimiento),
                id_carrera = COALESCE(NULLIF(?, 0), id_carrera),
                cuatrimestre_actual = COALESCE(NULLIF(?, ''), cuatrimestre_actual), 
                estatus = COALESCE(NULLIF(?, ''), estatus)
                WHERE id = ?");
                $stmt->bind_param(
                    "sssssssiis", 
                    $matricula, 
                    $nombre, 
                    $apellido_paterno,
                    $apellido_materno,
                    $correo,
                    $telefono,
                    $fecha_nacimiento,
                    $id_carrera,
                    $cuatrimestre_actual,
                    $estatus);
                if ($stmt->execute()) {
                    http_response_code(200);
                    echo json_encode(array("mensaje" => "Alumno actualizado exitosamente"), JSON_UNESCAPED_UNICODE);
                } else {
                    http_response_code(500);
                    echo json_encode(array("mensaje" => "Error al actualizar Alumno: " . $stmt->error), JSON_UNESCAPED_UNICODE);
                }
            } else {
                http_response_code(400);
                echo json_encode(array("mensaje" => "Al menos un campo es obligatorio para actualizar al alumno"), JSON_UNESCAPED_UNICODE);
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar algun alumno"), JSON_UNESCAPED_UNICODE);
        }
        break;
    case 'DELETE':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("DELETE FROM alumnos WHERE id = ?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("mensaje" => "Datos del alumno eliminados exitosamente"), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al eliminar los datos del alumno: " . $stmt->error), JSON_UNESCAPED_UNICODE);
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para eliminar los datois de algun alumno"), JSON_UNESCAPED_UNICODE);
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Método no permitido"), JSON_UNESCAPED_UNICODE);
        break;
}