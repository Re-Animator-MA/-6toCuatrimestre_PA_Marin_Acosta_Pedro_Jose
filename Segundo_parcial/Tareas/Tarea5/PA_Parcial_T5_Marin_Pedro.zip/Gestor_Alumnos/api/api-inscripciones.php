<?php 
require_once "../config/conexion.php";

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
    $conn->close();
    exit;
}
switch ($method){
    case 'GET':
        if (isset($_GET['todas']) && strtolower(trim($_GET['todas'])) === 'true') {
            $stmt = $conn->prepare("SELECT 
                inscripciones.id,
                alumnos.nombre AS alumno,
                alumnos.apellido_paterno,
                alumnos.apellido_materno,
                materias.nombre AS materia,
                materias.creditos,
                inscripciones.fecha_inscripcion,
                inscripciones.calificacion,
                inscripciones.periodo
                FROM inscripciones
                INNER JOIN alumnos ON inscripciones.id_alumno = alumnos.id
                INNER JOIN materias ON inscripciones.id_materia = materias.id
                ORDER BY id;");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $inscripciones = array();
            while ($row = $resultado->fetch_assoc()) {
                $inscripciones[] = $row;
            }
            http_response_code(200);
            echo json_encode($inscripciones, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        }elseif (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $stmt = $conn->prepare("SELECT 
                inscripciones.id,
                alumnos.nombre AS alumno,
                alumnos.apellido_paterno,
                alumnos.apellido_materno,
                materias.nombre AS materia,
                materias.creditos,
                inscripciones.fecha_inscripcion,
                inscripciones.calificacion,
                inscripciones.periodo
                FROM inscripciones
                INNER JOIN alumnos ON inscripciones.id_alumno = alumnos.id
                INNER JOIN materias ON inscripciones.id_materia = materias.id
                WHERE alumno.nombre LIKE ? ");
            $nombre_param = "%$nombre%";
            $stmt->bind_param("s", $nombre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $inscripciones = array();
            if ($resultado->num_rows > 0) {
                while ($row = $resultado->fetch_assoc()) {
                    $inscripciones[] = $row;
                }
                http_response_code(200);
                echo json_encode($inscripciones, JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Materia no encontrada"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        } elseif (isset($_GET['materia'])) {
            $materia = trim($_GET['materia']);
            $stmt = $conn->prepare("SELECT 
            inscripciones.id,
                alumnos.nombre AS alumno,
                alumnos.apellido_paterno,
                alumnos.apellido_materno,
                materias.nombre AS materia,
                materias.creditos,
                inscripciones.fecha_inscripcion,
                inscripciones.calificacion,
                inscripciones.periodo
                FROM inscripciones
                INNER JOIN alumnos ON inscripciones.id_alumno = alumnos.id
                INNER JOIN materias ON inscripciones.id_materia = materias.id
                WHERE matyeria.nombre LIKE ? ");
            $materia_param = "%$materia%";
            $stmt->bind_param("s", $materia_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $inscripciones = array();
            if ($resultado->num_rows > 0) {
                while ($row = $resultado->fetch_assoc()) {
                    $inscripciones[] = $row;
                }
                http_response_code(200);
                echo json_encode($inscripciones, JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "materia no encontrada"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        }
        break;
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $id_alumno = intval($data['id_alumno'] ?? 0);
        $id_materia = intval($data['id_materia'] ?? 0);
        $fecha_inscripcion = trim($data['fecha_inscripcion'] ?? "");
        $calificacion = doubleval($data['calificacion'] ?? 0.0);
        $periodo = trim($data['periodo'] ?? "");
        if (!empty($id_alumno)) {
            $stmt = $conn->prepare("INSERT INTO inscripciones 
            (id_alumno,
            id_materia,
            fecha_inscripcion,
            calificacion,
            periodo) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param(
                "iisds",
                $id_alumno,
                $id_materia,
                $fecha_inscripcion,
                $calificacion,
                $periodo);
            if ($stmt->execute()) {
                http_response_code(201);
                echo json_encode(array("mensaje" => "Inscripción añadida exitosamente"), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al añadir inscripción: " . $stmt->error), JSON_UNESCAPED_UNICODE);
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El nombre completo es obligatorio"), JSON_UNESCAPED_UNICODE);
        }
        break;
    case 'DELETE':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("DELETE FROM inscripciones WHERE id = ?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("mensaje" => "Datos de inscripción eliminados exitosamente"), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al eliminar los datos de inscripción: " . $stmt->error), JSON_UNESCAPED_UNICODE);
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para eliminar los datois de inscripción"), JSON_UNESCAPED_UNICODE);
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Método no permitido"), JSON_UNESCAPED_UNICODE);
        break;
}