<?php 
require_once "../config/conexion.php";

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
    $conn->close();
    exit;
}
switch ($method){
    case 'GET':
        if (isset($_GET['todas']) && strtolower(trim($_GET['todas'])) === 'true') {
            $stmt = $conn->prepare("SELECT 
            materias.id,
            materias.nombre AS materia,
            materias.creditos, 
            materias.id_carrera,
            carreras.nombre AS carrera,
            materias.id_cuatrimestre,
            cuatrimestres.nombre AS cuatrimestre
            FROM materias INNER JOIN carreras
            ON materias.id_carrera = carreras.id
            INNER JOIN cuatrimestres
            ON materias.id_cuatrimestre = cuatrimestres.id
            ORDER BY carrera, cuatrimestre, carrera");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $materias = array();
            while ($row = $resultado->fetch_assoc()) {
                $materias[] = $row;
            }
            http_response_code(200);
            echo json_encode($materias, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        } elseif (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $stmt = $conn->prepare("SELECT 
            materias.id,
            materias.nombre AS materia,
            materias.creditos, 
            materias.id_carrera,
            carreras.nombre AS carrera,
            materias.id_cuatrimestre,
            cuatrimestres.nombre AS cuatrimestre
            FROM materias INNER JOIN carreras
            ON materias.id_carrera = carreras.id
            INNER JOIN cuatrimestres
            ON materias.id_cuatrimestre = cuatrimestres.id
            WHERE materias.nombre LIKE ?
            ORDER BY carrera, cuatrimestre, carrera ");
            $nombre_param = "%$nombre%";
            $stmt->bind_param("s", $nombre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $materias = array();
            if ($resultado->num_rows > 0) {
                while ($row = $resultado->fetch_assoc()) {
                    $materias[] = $row;
                }
                http_response_code(200);
                echo json_encode($materias, JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Materia no encontrada"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        } elseif (isset($_GET['carrera'])) {
            $carrera = trim($_GET['carrera']);
            $stmt = $conn->prepare("SELECT 
            materias.id,
            materias.nombre AS materia,
            materias.creditos, 
            materias.id_carrera,
            carreras.nombre AS carrera,
            materias.id_cuatrimestre,
            cuatrimestres.nombre AS cuatrimestre
            FROM materias INNER JOIN carreras
            ON materias.id_carrera = carreras.id
            INNER JOIN cuatrimestres
            ON materias.id_cuatrimestre = cuatrimestres.id
            WHERE carreras.nombre LIKE ?
            ORDER BY carrera, cuatrimestre, carrera ");
            $carrera_param = "%$carrera%";
            $stmt->bind_param("s", $carrera_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $carreras = array();
            if ($resultado->num_rows > 0) {
                while ($row = $resultado->fetch_assoc()) {
                    $carreras[] = $row;
                }
                http_response_code(200);
                echo json_encode($carreras, JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "materia no encontrada"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        } elseif (isset($_GET['cuatrimestre'])) {
            $cuatrimestre = trim($_GET['cuatrimestre']);
            $stmt = $conn->prepare("SELECT 
            materias.id,
            materias.nombre AS materia,
            materias.creditos, 
            materias.id_carrera,
            carreras.nombre AS carrera,
            materias.id_cuatrimestre,
            cuatrimestres.nombre AS cuatrimestre
            FROM materias INNER JOIN carreras
            ON materias.id_carrera = carreras.id
            INNER JOIN cuatrimestres
            ON materias.id_cuatrimestre = cuatrimestres.id
            WHERE cuatrimestre LIKE ?
            ORDER BY carrera, cuatrimestre, carrera ");
            $cuatrimestre_param = "%$cuatrimestre%";
            $stmt->bind_param("s", $cuatrimestre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $cuatrimestres = array();
            if ($resultado->num_rows > 0) {
                while ($row = $resultado->fetch_assoc()) {
                    $cuatrimestres[] = $row;
                }
                http_response_code(200);
                echo json_encode($cuatrimestres, JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Materia no encontrada"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        }else {
            $stmt = $conn->prepare("SELECT 
            materias.id,
            materias.nombre AS materia,
            materias.creditos, 
            materias.id_carrera,
            carreras.nombre AS carrera,
            materias.id_cuatrimestre,
            cuatrimestres.nombre AS cuatrimestre
            FROM materias INNER JOIN carreras
            ON materias.id_carrera = carreras.id
            INNER JOIN cuatrimestres
            ON materias.id_cuatrimestre = cuatrimestres.id
            ORDER BY carrera, cuatrimestre, carrera");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $materias = array();
            while ($row = $resultado->fetch_assoc()) {
                $materias[] = $row;
            }
            http_response_code(200);
            echo json_encode($materias, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        }
        //$conn -> close();
        break;
        default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Método no permitido"), JSON_UNESCAPED_UNICODE);
        break;
}