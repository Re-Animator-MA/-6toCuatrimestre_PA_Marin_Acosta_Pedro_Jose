<?php
    $host = "localhost";
    $user = "general";
    $password = "pr1m3r#5#4r10";
    $database = "gestor_alumnos";

    $datos = [$host, $user, $password, $database];
?>