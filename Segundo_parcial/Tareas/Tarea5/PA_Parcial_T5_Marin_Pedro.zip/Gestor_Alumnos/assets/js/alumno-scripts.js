//const URL_BASE = 'http://localhost/Gestor_Alumnos/api/';

// GET ../api/api-alumnos.php — listar todos
async function getAlumnos() {
    const tbody = document.querySelector('#tabla-alumnos tbody');
    if (!tbody) {
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-alumnos.php`);
        const data = await response.json();
        console.log("Respuesta de la API:", data);
        tbody.innerHTML = '';
        data.forEach(alumno => {
            console.log("Pintando alumno:", alumno); 
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${alumno.id}</td>
                <td>${alumno.matricula}</td>
                <td>${alumno.nombre} ${alumno.apellido_paterno} ${alumno.apellido_materno}</td>
                <td>${alumno.correo}</td>
                <td>${alumno.telefono}</td>
                <td>${alumno.fecha_nacimiento}</td>
                <td>${alumno.carrera}</td>
                <td>${alumno.cuatrimestre_actual}</td>
                <td>${alumno.estatus}</td>
                <td>
                    <button class="button_warning" onclick="redirigirEditarAlumnos(${alumno.id})">
                        <i class="fas fa-edit"></i>Editar
                    </button>
                    <button class="button_danger" onclick="eliminarDatoAlumno(${alumno.id})">
                        <i class="fas fa-trash"></i>Eliminar
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        })
    } catch (error) {
        console.error('Error al obtener los alumnos: ', error);
    }
}
// GET ../api/api-alumnos.php?nombre=texto — buscar por nombre
async function buscarAlumnosPorNombre(nombre){
    const tbody = document.querySelector('#tabla-alumnos tbody');
    if(!tbody) {
        return;
    }
    try{
        const response = await fetch(`${URL_BASE}api-categorias.php?nombre=${encodeURIComponent(nombre)}`);
        const data = await response.json();
        tbody.innerHTML = '';
        if (response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(alumno => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                <td>${alumno.id}</td>
                <td>${alumno.matricula}</td>
                <td>${alumno.nombre} ${alumno.apellido_paterno} ${alumno.apellido_materno}</td>
                <td>${alumno.correo}</td>
                <td>${alumno.telefono}</td>
                <td>${alumno.fecha_nacimiento}</td>
                <td>${alumno.carrera}</td>
                <td>${alumno.cuatrimestre_actual}</td>
                <td>${alumno.estatus}</td>
                <td>
                    <button class="button_warning" onclick="redirigirEditarAlumnos(${alumno.id})'">
                        <i class="fas fa-edit"></i>Editar
                    </button>
                    <button class="button_danger" onclick=eliminarDatoAlumno(${alumno.id})'">
                        <i class="fas fa-trash"></i>Eliminar
                    </button>
                </td>
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron alumnos</td>
                </tr>
            `;
        }
    }catch(error){
        console.error('Error al buscar categorias: ', error);
        tbody.innerHTML = `
             <tr>
                <td colspan="4" style="text-align:center;color:#666;">Error al buscar Alumnos</td>
            </tr>
        `;
    }
}

// GET ../api/api-alumnos.php?id=1 — obtener una por ID
async function getAlumnoPorId(id) {
    const tbody = document.querySelector('#tabla-alumnos tbody');
    if(!tbody) {
        return;
    }
    try{
        const response = await fetch(`${URL_BASE}api-categorias.php?nombre=${encodeURIComponent(id)}`);
        const data = await response.json();
        tbody.innerHTML = '';
        if (response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(alumno => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                <td>${alumno.id}</td>
                <td>${alumno.matricula}</td>
                <td>${alumno.nombre} ${alumno.apellido_paterno} ${alumno.apellido_materno}</td>
                <td>${alumno.correo}</td>
                <td>${alumno.telefono}</td>
                <td>${alumno.fecha_nacimiento}</td>
                <td>${alumno.carrera}</td>
                <td>${alumno.cuatrimestre_actual}</td>
                <td>${alumno.estatus}</td>
                <td>
                    <button class="button_warning" onclick="redirigirEditarAlumnos(${alumno.id})'">
                        <i class="fas fa-edit"></i>Editar
                    </button>
                    <button class="button_danger" onclick=eliminarDatoAlumno(${alumno.id})'">
                        <i class="fas fa-trash"></i>Eliminar
                    </button>
                </td>
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron alumnos</td>
                </tr>
            `;
        }
    }catch(error){
        console.error('Error al buscar categorias: ', error);
        tbody.innerHTML = `
             <tr>
                <td colspan="4" style="text-align:center;color:#666;">Error al buscar Alumnos</td>
            </tr>
        `;
    }
}
// GET ../api/api-alumnos.php?matricula=texto — buscar por matricula
async function buscarAlumnosPorMatricula(matricula){
    const tbody = document.querySelector('#tabla-alumnos tbody');
    if(!tbody) {
        return;
    }
    try{
        const response = await fetch(`${URL_BASE}api-categorias.php?nombre=${encodeURIComponent(matricula)}`);
        const data = await response.json();
        tbody.innerHTML = '';
        if (response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(alumno => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                <td>${alumno.id}</td>
                <td>${alumno.matricula}</td>
                <td>${alumno.nombre} ${alumno.apellido_paterno} ${alumno.apellido_materno}</td>
                <td>${alumno.correo}</td>
                <td>${alumno.telefono}</td>
                <td>${alumno.fecha_nacimiento}</td>
                <td>${alumno.carrera}</td>
                <td>${alumno.cuatrimestre_actual}</td>
                <td>${alumno.estatus}</td>
                <td>
                    <button class="button_warning" onclick="redirigirEditarAlumnos(${alumno.id})'">
                        <i class="fas fa-edit"></i>Editar
                    </button>
                    <button class="button_danger" onclick=eliminarDatoAlumno(${alumno.id})'">
                        <i class="fas fa-trash"></i>Eliminar
                    </button>
                </td>
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron alumnos</td>
                </tr>
            `;
        }
    }catch(error){
        console.error('Error al buscar categorias: ', error);
        tbody.innerHTML = `
             <tr>
                <td colspan="4" style="text-align:center;color:#666;">Error al buscar Alumnos</td>
            </tr>
        `;
    }
}
// GET ../api/api-alumnos.php?carrera=texto — buscar por carrera
async function buscarAlumnosPorCarrera(carrera){
    const tbody = document.querySelector('#tabla-alumnos tbody');
    if(!tbody) {
        return;
    }
    try{
        const response = await fetch(`${URL_BASE}api-categorias.php?nombre=${encodeURIComponent(carrera)}`);
        const data = await response.json();
        tbody.innerHTML = '';
        if (response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(alumno => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                <td>${alumno.id}</td>
                <td>${alumno.matricula}</td>
                <td>${alumno.nombre} ${alumno.apellido_paterno} ${alumno.apellido_materno}</td>
                <td>${alumno.correo}</td>
                <td>${alumno.telefono}</td>
                <td>${alumno.fecha_nacimiento}</td>
                <td>${alumno.carrera}</td>
                <td>${alumno.cuatrimestre_actual}</td>
                <td>${alumno.estatus}</td>
                <td>
                    <button class="button_warning" onclick="redirigirEditarAlumnos(${alumno.id})'">
                        <i class="fas fa-edit"></i>Editar
                    </button>
                    <button class="button_danger" onclick=eliminarDatoAlumno(${alumno.id})'">
                        <i class="fas fa-trash"></i>Eliminar
                    </button>
                </td>
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron alumnos</td>
                </tr>
            `;
        }
    }catch(error){
        console.error('Error al buscar categorias: ', error);
        tbody.innerHTML = `
             <tr>
                <td colspan="4" style="text-align:center;color:#666;">Error al buscar Alumnos</td>
            </tr>
        `;
    }
}
// POST ../api/api-alumnos.php — registrar (body: {matricuula, nombre, tec})
async function registrarAlumno(
    matricula,
    nombre, 
    apellido_paterno,
    apellido_materno,
    correo,
    telefono,
    fecha_nacimiento,
    id_carrera,
    cuatrimistre_actual,
    estatus
    ) {
    try {
        const nuevoAlumno = {
            matricula,
            nombre,
            apellido_paterno,
            apellido_materno,
            correo,
            telefono,
            fecha_nacimiento,
            id_carrera,
            cuatrimestre_actual,
            estatus
        };
        const response = await fetch(`${URL_BASE}api-alumnos.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(nuevoAlumno)
        })
        if (response.ok) {
            window.location.replace('views/alumnos.php'); 
            return;
        } else {
            const errorData = await response.json().catch(() => null);
            const mensaje = errorData?.mensaje || response.statusText || 'Error al registrar al alumno';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al registrar al alumno: ', error);
    }
}
// PUT ../api/api-alumnos.php?id=1 — actualizar completa (body: {matricula, nombre, ....})
async function actualizarAlumno(
    id,
    matricula,
    nombre, 
    apellido_paterno,
    apellido_materno,
    correo,
    telefono,
    fecha_nacimiento,
    id_carrera,
    cuatrimistre_actual,
    estatus
) {
    const alumnoActualizado = {
        matricula,
            nombre,
            apellido_paterno,
            apellido_materno,
            correo,
            telefono,
            fecha_nacimiento,
            id_carrera,
            cuatrimestre_actual,
            estatus
    }
    try {
        const response = await fetch(`${URL_BASE}api-alumnos.php?id=${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(alumnoActualizado)
        })
        if (response.ok) {
            window.location.replace('views/alumnos.php');
            return;
        } else {
            const errorData = await response.json().catch(() => null); 
            const mensaje = errorData?.mensaje || response.statusText || 'Error al actualizar al alumno';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al actualizar al alumno: ', error);
    }
}
async function actualizarAlumnoPatch(id, cuatrimistre_actual, estatus){
    try{
        const alumnoActualizadoP = {
            cuatrimestre_actual,
            estatus
        };
        const response = await fetch(`${URL_BASE}api-alumnos.php?id=${id}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(alumnoActualizadoP)
        });
        
        if (response.ok) {
            const data =await response.json();
            window.location.replace('views/alumnos.php');
            
        } else {
            const errorData = await response.json().catch(() => null); 
            const mensaje = errorData?.mensaje || response.statusText || 'Error al actualizar al alumno';
            console.log(mensaje);
        }
    }catch(error){
         console.error('Error al actualizar al alumno: ', error);
    }
}

// DELETE ../api/api-alumnos.php?id=1 — eliminar
async function eliminarDatoAlumno(id) {
    try {
        const response = await fetch(`${URL_BASE}api-alumnos.php?id=${id}`, {
            method: 'DELETE'
        });
        if (response.ok) {
            window.location.replace('views/alumnos.php');
            return;
        } else {
            const errorData = await response.json().catch(() => null); 
            const mensaje = errorData?.mensaje || response.statusText || 'Error al eliminar los datos del alumno';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al eliminar los datos del alumno: ', error);
    }
}
async function eventoRegistrarAlumno() {
    event.preventDefault();
    const matricula = document.getElementById('matricula').value.trim(); 
    const nombre = document.getElementById('nombre').value.trim();
    const apellido_paterno  = document.getElementById('apellido_paterno').value.trim(); 
    const apellido_materno  = document.getElementById('apellido_materno').value.trim();
    const correo  = document.getElementById('correo').value.trim();
    const telefono  = document.getElementById('telefono').value.trim();
    const fecha_nacimiento  = document.getElementById('fecha_nacimiento').value.trim();
    const id_carrera  = parseInt(document.getElementById('id_carrera').value.trim(), 10);
    const cuatrimestre_actual  = document.getElementById('cuatrimestre_actual').value.trim();
    const estatus  = document.getElementById('estatus').value.trim(); 
    if (!nombre || !apellido_paterno || !apellido_materno) {
        console.log('El nombre completo es obligatorio');
        return;
    }
    
    await registrarAlumno(
        matricula,
        nombre,
        apellido_paterno,
        apellido_materno,
        correo,
        telefono,
        fecha_nacimiento,
        id_carrera,
        cuatrimestre_actual,
        estatus
    );
}
async function poblarFormularioEdicionAlu(id) {
    const alumno = await getAlumnoPorId(id);
    if (alumno) {
        document.getElementById('matricula').value = alumno.matricula;
        document.getElementById('nombre').value = alumno.nombre;
        document.getElementById('apellido_paterno').value = alumno.apellido_paterno;
        document.getElementById('apellido_materno').value = alumno.apellido_materno;
        document.getElementById('correo').value = alumno.correo;
        document.getElementById('telefono').value = alumno.telefono;
        document.getElementById('fecha_nacimiento').value = alumno.fecha_nacimiento;
        document.getElementById('id_carrera').value = alumno.id_carrera;
        document.getElementById('cuatrimestre_actual').value = alumno.cuatrimestre_actual;
        document.getElementById('estatus').value = alumno.estatus;
    } else {
        console.log('No se pudo poblar el formulario de edición: alumno no encontrado');
    }
}
async function redirigirEditarAlumnos(id) {
    window.location.href = `views/actions-alumnos/edit-alumno.php?id=${id}`; 
}
async function obtenerId() {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');
    if (id) {
        return id;
    } else {
        console.log('No se proporcionó un ID de Alumno para editar');
        return null;
    }
}
document.addEventListener('DOMContentLoaded', () => {
    getAlumnos();

    const alumnosCreateForm = document.getElementById('alumno-create-form');
    const alumnosEditForm = document.getElementById('alumno-edit-form');
    if (alumnosCreateForm) {
        alumnosCreateForm.addEventListener('submit', (event) => {
            event.preventDefault(); 
            eventoRegistrarAlumno();
        });
    }
    if (alumnosEditForm) {
        obtenerIdAlumno().then((id) => { 
            if (id) {
                poblarFormularioEdicionAlu(id);
            } else {
                console.log('No se proporcionó un ID de categoría para editar');
            }
        });
        alumnosEditForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const matricula = document.getElementById('matricula').value.trim(); 
            const nombre = document.getElementById('nombre').value.trim();
            const apellido_paterno  = document.getElementById('apellido_paterno').value.trim(); 
            const apellido_materno  = document.getElementById('apellido_materno').value.trim();
            const correo  = document.getElementById('correo').value.trim();
            const telefono  = document.getElementById('telefono').value.trim();
            const fecha_nacimiento  = document.getElementById('fecha_nacimiento').value.trim();
            const id_carrera  = parseInt(document.getElementById('id_carrera').value.trim(), 10);
            const cuatrimestre_actual  = document.getElementById('cuatrimestre_actual').value.trim();
            const estatus  = document.getElementById('estatus').value.trim();

            const soloActualizarEstatusOCuatrimestre = document.getElementById('soloActualizarEstatus').checked;
            obtenerIdAlumno().then((id) => { 
                if (id) {
                    if(soloActualizarEstatusOCuatrimestre){
                        actualizarAlumnoPatch(id, cuatrimestre_actual, estatus);
                    }else{
                        actualizarAlumno(
                            id, matricula, nombre, apellido_paterno, apellido_materno, correo, telefono, fecha_nacimiento, cuatrimestre_actual, estatus
                        );
                    }
                } else {
                    console.log('No se proporcionó un ID de categoría para actualizar');
                }
            });
        });
    }

    const searchInput = document.getElementById('search-input');
    if(searchInput){
        searchInput.addEventListener('input', (event) => {
            const valor = event.target.value.trim();
            if(valor){
                getAlumnoPorId(valor);
                buscarAlumnosPorMatricula(valor);
                buscarAlumnosPorNombre(valor);
                buscarAlumnosPorCarrera(valor);
            }else{
                getAlumnos();
            }
        });
    }
});