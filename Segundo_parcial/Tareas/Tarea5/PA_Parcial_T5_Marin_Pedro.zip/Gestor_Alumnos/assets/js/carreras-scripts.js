//const URL_BASE = 'http://localhost/Gestor_Alumnos/api/';

// GET ../api/api-carreras.php — listar todass
async function getCarreras() {
    const tbody = document.querySelector('#tabla-carreras tbody');
    if (!tbody) {
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-carreras.php`);
        const data = await response.json();
        console.log("Respuesta de la API:", data);
        tbody.innerHTML = '';
        data.forEach(carrera => {
            console.log("Pintando carrera:", carrera); 
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${carrera.id}</td>
                <td>${carrera.nombre}</td>
            `;
            tbody.appendChild(tr);
        })
    } catch (error) {
        console.error('Error al obtener las carreras: ', error);
    }
}
// GET ../api/api-carreras.php?id=1 — obtener una por ID
async function getCarreraPorId(id) {
    const tbody = document.querySelector('#tabla-carreras tbody');
    if(!tbody) {
        return;
    }
    try{
        const response = await fetch(`${URL_BASE}api-carreras.php?id=${encodeURIComponent(id)}`);
        const data = await response.json();
        tbody.innerHTML = '';
        if (response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(carrera => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                <td>${carrera.id}</td>
                <td>${carrera.nombre}</td>
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron carreras</td>
                </tr>
            `;
        }
    }catch(error){
        console.error('Error al buscar categorias: ', error);
        tbody.innerHTML = `
             <tr>
                <td colspan="4" style="text-align:center;color:#666;">Error al buscar Carreras</td>
            </tr>
        `;
    }
}
document.addEventListener('DOMContentLoaded', () => {
    getCarreras();
    const searchInput = document.getElementById('search-input-carreras');
    if(searchInput){
        searchInput.addEventListener('input', (event) => {
            const valor = event.target.value.trim();
            if(valor){
                getCarreraPorId(valor);
            }else{
                getCarreras();
            }
        });
    }
});