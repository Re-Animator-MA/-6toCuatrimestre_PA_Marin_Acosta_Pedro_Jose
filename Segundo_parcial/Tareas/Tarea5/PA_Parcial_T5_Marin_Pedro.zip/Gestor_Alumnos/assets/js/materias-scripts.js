// GET ../api/api-materias.php — listar todas
async function getMaterias() {
    const tbody = document.querySelector('#tabla-materias tbody');
    if (!tbody) {
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-materias.php`);
        const data = await response.json();
        console.log("Respuesta de la API:", data);
        tbody.innerHTML = '';
        data.forEach(materia => {
            console.log("Pintando materia:", materia); 
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${materia.id}</td>
                <td>${materia.materia}</td>
                <td>${materia.creditos}</td>
                <td>id.${materia.id_carrera}, ${materia.carrera}</td>
                <td>id.${materia.id_cuatrimestre}, ${materia.cuatrimestre}</td>
            `;
            tbody.appendChild(tr);
        })
    } catch (error) {
        console.error('Error al obtener los alumnos: ', error);
    }
}
// GET ../api/api-materias.php?materia=texto — buscar por nombre
async function buscarMateriasPorNombre(nombre){
    const tbody = document.querySelector('#tabla-materias tbody');
    if(!tbody) {
        return;
    }
    try{
        const response = await fetch(`${URL_BASE}api-materias.php?nombre=${encodeURIComponent(nombre)}`);
        const data = await response.json();
        tbody.innerHTML = '';
        if (response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(materia => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                <td>${materia.id}</td>
                <td>${materia.materia}</td>
                <td>${materia.creditos}</td>
                <td>id.${materia.id_carrera}, ${materia.carrera}</td>
                <td>id.${materia.id_cuatrimestre}, ${materia.cuatrimestre}</td>
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron materias</td>
                </tr>
            `;
        }
    }catch(error){
        console.error('Error al buscar categorias: ', error);
        tbody.innerHTML = `
             <tr>
                <td colspan="4" style="text-align:center;color:#666;">Error al buscar Materias</td>
            </tr>
        `;
    }
}
async function buscarMateriasPorCarrera(carrera){
    const tbody = document.querySelector('#tabla-materias tbody');
    if(!tbody) {
        return;
    }
    try{
        const response = await fetch(`${URL_BASE}api-materias.php?carreras=${encodeURIComponent(carrera)}`);
        const data = await response.json();
        tbody.innerHTML = '';
        if (response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(materia => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                <td>${materia.id}</td>
                <td>${materia.materia}</td>
                <td>${materia.creditos}</td>
                <td>id.${materia.id_carrera}, ${materia.carrera}</td>
                <td>id.${materia.id_cuatrimestre}, ${materia.cuatrimestre}</td>
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron materias</td>
                </tr>
            `;
        }
    }catch(error){
        console.error('Error al buscar categorias: ', error);
        tbody.innerHTML = `
             <tr>
                <td colspan="4" style="text-align:center;color:#666;">Error al buscar Materias</td>
            </tr>
        `;
    }
}
async function buscarMateriasPorCuatrimestre(cuatrimestre){
    const tbody = document.querySelector('#tabla-materias tbody');
    if(!tbody) {
        return;
    }
    try{
        const response = await fetch(`${URL_BASE}api-materias.php?cuatrimestre=${encodeURIComponent(cuatrimestre)}`);
        const data = await response.json();
        tbody.innerHTML = '';
        if (response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(materia => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                <td>${materia.id}</td>
                <td>${materia.materia}</td>
                <td>${materia.creditos}</td>
                <td>id.${materia.id_carrera}, ${materia.carrera}</td>
                <td>id.${materia.id_cuatrimestre}, ${materia.cuatrimestre}</td>
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron materias</td>
                </tr>
            `;
        }
    }catch(error){
        console.error('Error al buscar categorias: ', error);
        tbody.innerHTML = `
             <tr>
                <td colspan="4" style="text-align:center;color:#666;">Error al buscar Materias</td>
            </tr>
        `;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    getMaterias();

    const searchInput = document.getElementById('search-input-materias');
    if(searchInput){
        searchInput.addEventListener('input', (event) => {
            const valor = event.target.value.trim();
            if(valor){
                buscarMateriasPorNombre(valor);
                buscarMateriasPorCarrera(valor);
                buscarMateriasPorCuatrimestre(valor);
            }else{
                getMaterias();
            }
        });
    }
});