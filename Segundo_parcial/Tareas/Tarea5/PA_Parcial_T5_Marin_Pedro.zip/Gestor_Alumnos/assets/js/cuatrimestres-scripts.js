
async function getCuatrimestres() {
    const tbody = document.querySelector('#tabla-cuatrimestre tbody');
    if (!tbody) {
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-cuatrimestres.php`);
        const data = await response.json();
        console.log("Respuesta de la API:", data);
        tbody.innerHTML = '';
        data.forEach(cuatrimestre => {
            console.log("Pintando cuatrimestre:", cuatrimestre); 
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${cuatrimestre.id}</td>
                <td>${cuatrimestre.nombre}</td>
            `;
            tbody.appendChild(tr);
        })
    } catch (error) {
        console.error('Error al obtener las carreras: ', error);
    }
}
document.addEventListener('DOMContentLoaded', () => {
    getCuatrimestres();
});