async function getInscripciones() {
    const tbody = document.querySelector('#tabla-inscripciones tbody');
    if (!tbody) {
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-inscripciones.php`);
        const data = await response.json();
        console.log("Respuesta de la API:", data);
        tbody.innerHTML = '';
        data.forEach(inscripcion => {
            console.log("Pintando alumno:", alumno); 
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${inscripcion.id}</td>
                <td>${inscripcion.nombre} ${inscripcion.apellido_paterno} ${inscripcion.apellido_materno}</td>
                <td>${inscripcion.materia}</td>
                <td>${inscripcion.fecha_inscripcion}</td>
                <td>${inscripcion.calificacion}</td>
                <td>${inscripcion.periodo}</td>
                <td>
                    <button class="button_danger" onclick="eliminarInscripcion(${inscripcion.id})">
                        <i class="fas fa-trash"></i>Eliminar
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        })
    } catch (error) {
        console.error('Error al obtener las inscripciones: ', error);
    }
}

async function buscarInscripcionPorAlumno(nombre){
    const tbody = document.querySelector('#tabla-inscripciones tbody');
    if(!tbody) {
        return;
    }
    try{
        const response = await fetch(`${URL_BASE}api-inscripciones.php?nombre=${encodeURIComponent(nombre)}`);
        const data = await response.json();
        tbody.innerHTML = '';
        if (response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(inscripcion => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                <td>${inscripcion.id}</td>
                <td>${inscripcion.nombre} ${inscripcion.apellido_paterno} ${inscripcion.apellido_materno}</td>
                <td>${inscripcion.materia}</td>
                <td>${inscripcion.fecha_inscripcion}</td>
                <td>${inscripcion.calificacion}</td>
                <td>${inscripcion.periodo}</td>
                <td>
                    <button class="button_danger" onclick="eliminarInscripcion(${inscripcion.id})">
                        <i class="fas fa-trash"></i>Eliminar
                    </button>
                </td>
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron Inscripciónes</td>
                </tr>
            `;
        }
    }catch(error){
        console.error('Error al buscar categorias: ', error);
        tbody.innerHTML = `
             <tr>
                <td colspan="4" style="text-align:center;color:#666;">Error al buscar Inscripciones</td>
            </tr>
        `;
    }
}
async function buscarInscripcionPorMateria(materia){
    const tbody = document.querySelector('#tabla-inscripciones tbody');
    if(!tbody) {
        return;
    }
    try{
        const response = await fetch(`${URL_BASE}api-inscripciones.php?materia=${encodeURIComponent(materia)}`);
        const data = await response.json();
        tbody.innerHTML = '';
        if (response.ok && Array.isArray(data) && data.length > 0){
            data.forEach(inscripcion => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                <td>${inscripcion.id}</td>
                <td>${inscripcion.nombre} ${inscripcion.apellido_paterno} ${inscripcion.apellido_materno}</td>
                <td>${inscripcion.materia}</td>
                <td>${inscripcion.fecha_inscripcion}</td>
                <td>${inscripcion.calificacion}</td>
                <td>${inscripcion.periodo}</td>
                <td>
                    <button class="button_danger" onclick="eliminarInscripcion(${inscripcion.id})">
                        <i class="fas fa-trash"></i>Eliminar
                    </button>
                </td>
                `;
                tbody.appendChild(tr);
            });
        }else{
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align:center;color:#666;">No se encontraron Inscripciónes</td>
                </tr>
            `;
        }
    }catch(error){
        console.error('Error al buscar categorias: ', error);
        tbody.innerHTML = `
             <tr>
                <td colspan="4" style="text-align:center;color:#666;">Error al buscar Inscripciones</td>
            </tr>
        `;
    }
}
async function registrarInscripcion(
    nombre, 
    id_alumno,
    id_materia,
    fecha_inscripcion,
    calificacion,
    periodo
    ) {
    try {
        const nuevaOnscripcion = {
            nombre, 
            id_alumno,
            id_materia,
            fecha_inscripcion,
            calificacion,
            periodo
        };
        const response = await fetch(`${URL_BASE}api-inscripciones.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(nuevaOnscripcion)
        })
        if (response.ok) {
            window.location.replace('views/inscripciones.php'); 
            return;
        } else {
            const errorData = await response.json().catch(() => null);
            const mensaje = errorData?.mensaje || response.statusText || 'Error al registrar Inscripción';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al registrar al alumno: ', error);
    }
}
async function eventoRegistrarAlumno() {
    event.preventDefault();
    const id_alumno  = parseInt(document.getElementById('id_alumno').value.trim(), 10); 
    const id_materia  = parseInt(document.getElementById('id_materia').value.trim(), 10);
    const fecha_inscripcion  = document.getElementById('correo').value.trim();
    const calificacion  = parseFloat(document.getElementById('id_alumno').value.trim());
    const periodo  = document.getElementById('fecha_nacimiento').value.trim();
    if (!id_alumno && !id_materia) {
        console.log('id_alumno y de materia son obligatorios');
        return;
    }
    
    await registrarInscripcion(
        id_alumno,
        id_materia,
        fecha_inscripcion,
        calificacion,
        periodo
    );
}

async function eliminarInscripciones(id) {
    try {
        const response = await fetch(`${URL_BASE}api-inscripciones.php?id=${id}`, {
            method: 'DELETE'
        });
        if (response.ok) {
            window.location.replace('views/inscripciones.php');
            return;
        } else {
            const errorData = await response.json().catch(() => null); 
            const mensaje = errorData?.mensaje || response.statusText || 'Error al eliminar los datos del alumno';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al eliminar la inscripcion: ', error);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    getMaterias();

    const searchInput = document.getElementById('search-input-inscripciones');
    if(searchInput){
        searchInput.addEventListener('input', (event) => {
            const valor = event.target.value.trim();
            if(valor){
                getInscripciones(valor);
                buscarInscripcionPorAlumno(valor);
                buscarInscripcionPorMateria(valor);
            }else{
                getMaterias();
            }
        });
    }
});