<?php
require_once('../config/connection.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

switch($method){
    case 'GET':
        if(!isset($_GET['id'])){
            $id = intval($_GET['id']);
            $stmt = $conn -> prepare("SELECT categorias.id, categorias.nombre, categorias.descripcion, libros.id, libros.titulo  FROM categorias 
            INNER JOIN libros  ON categorias.id = libros.id_categoria WHERE categorias.id = ?");
            $stmt -> bind_param("id", $id);
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            //$libros = array();
            if ($resultado -> num_rows > 0){
                $categoria = $resultado -> fetch_assoc();
                echo json_encode($categoria);
            }else{
                echo json_encode(array("mensaje" => "Titulo no encontrado"));
            }
            $stmt -> close();
            $conn -> close();
        }elseif(!isset($_GET['titulo'])){
            $titulo = trim($_GET['titulo']);
            $stmt = $conn -> prepare("SELECT libros.id, libros.titulo, categorias.nombre, categorias.descripcion FROM libros 
            INNER JOIN categorias ON libros.id_categoria = categorias.id WHERE libros.titulo LIKE ?");
            $titulo_param = "%$titulo%";
            $stmt -> bind_param("s", $nombre_param);
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            $titulos = array();
            if($resultado -> num_rows > 0){
                while($row = $resultado -> fetch_assoc()){
                    $titulos[] = $row;
                }
                echo json_encode($titulos);
            }else{
                echo json_encode(array("mensaje" => "Titulo no encontrado"));
            }
            $stmt -> close();
            $conn -> close();
        }else{
            $stmt = $conn -> prepare("SELECT categorias.id, libros.id, libros.titulo, categorias.nombre, categorias.descripcion FROM categorias 
            INNER JOIN libros ON categorias.id = libros.id_categoria");
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            $categorias = array();
            while($row = $resultado -> fetch_assoc()){
                $categorias[] = $row;
            }
            $respuesta = json_encode($categorias);
            echo $respuesta;
            $stmt -> close();
            $conn -> close();
        }
        break;
}