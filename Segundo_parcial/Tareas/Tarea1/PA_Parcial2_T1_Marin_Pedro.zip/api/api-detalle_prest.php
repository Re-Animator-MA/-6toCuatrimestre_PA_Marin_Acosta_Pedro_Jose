<?php
require_once('../config/connection.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

switch($method){
    case 'GET':
        if(!isset($_GET['id'])){
            $id = intval($_GET['id']);
            $stmt = $conn -> prepare("SELECT id, id_prestamo, id_libro, cantidad, FROM detalle_prestsmo WHERE id = ?");
            $stmt -> bind_param("id", $id);
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            //$libros = array();
            if ($resultado -> num_rows > 0){
                $dprestamo = $resultado -> fetch_assoc();
                echo json_encode($dprestamo);
            }else{
                echo json_encode(array("mensaje" => "detalle del prestamo no encontrado"));
            }
            $stmt -> close();
            $conn -> close();
        }elseif(!isset($_GET['titulo'])){
            $titulo = trim($_GET['titulo']);
            $stmt = $conn -> prepare("SELECT SELECT libros.titulo, detalle_prestamo.id, detalle_prestamo.id_prestamo, detalle_prestamo.id_libro, detalle_prestamo.cantidad, 
            FROM libros INNER JOIN detalle_prestsmo ON libros.id = detalle_prestamo.id_libro WHERE libros.titulo LIKE ?");
            $titulo_param = "%$titulo%";
            $stmt -> bind_param("s", $titulo_param);
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            $dprestamos = array();
            if($resultado -> num_rows > 0){
                while($row = $resultado -> fetch_assoc()){
                    $dprestamos[] = $row;
                }
                echo json_encode($dprestamos);
            }else{
                echo json_encode(array("mensaje" => "detalle del prestamo no encontrado"));
            }
            $stmt -> close();
            $conn -> close();
        }elseif(!isset($_GET['id_prestamo'])){
            $dprestamo = intval($_GET['estado']);
            $stmt = $conn -> prepare("SELECT id, id_prestamo, id_libro, cantidad, FROM detalle_prestsmos  WHERE id_prestamo = ?");
            $dprestamo_param = "%$dprestamo%";
            $stmt -> bind_param("id_prestamo", $dprestamo_param);
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            $dprestamos = array();
            if($resultado -> num_rows > 0){
                while($row = $resultado -> fetch_assoc()){
                    $dprestamos[] = $row;
                }
                echo json_encode($dprestamos);
            }else{
                echo json_encode(array("mensaje" => "detalle del prestamo no encontrado"));
            }
            $stmt -> close();
            $conn -> close();
        }else{
            $stmt = $conn -> prepare("SELECT id, id_prestamo, id_libro, cantidad, FROM detalle_prestsmo");
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            $dprestamos = array();
            while($row = $resultado -> fetch_assoc()){
                $dprestamos[] = $row;
            }
            $respuesta = json_encode($dprestamos);
            echo $respuesta;
            $stmt -> close();
            $conn -> close();
        }
        break;
}