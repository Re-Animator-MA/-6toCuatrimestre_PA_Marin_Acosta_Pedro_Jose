<?php
require_once('../config/connection.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

switch($method){
    case 'GET':
        if(!isset($_GET['activo'])){
            $activo = intval($_GET['activo']);
            $stmt = $conn -> prepare("SELECT id, nombre, apellido, correo, password, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE activo = ?");
            $activo_param = "%$activo%";
            $stmt -> bind_param("i", $activo);
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            $activos = array();
            //$libros = array();
            if ($resultado -> num_rows > 0){
                while($row = $resultado -> fetch_assoc()){
                    $activos[] = $row;
                }
                echo json_encode($activos);
            }else{
                echo json_encode(array("mensaje" => "Usuario no encontrados"));
            }
            $stmt -> close();
            $conn -> close();
        }
}   