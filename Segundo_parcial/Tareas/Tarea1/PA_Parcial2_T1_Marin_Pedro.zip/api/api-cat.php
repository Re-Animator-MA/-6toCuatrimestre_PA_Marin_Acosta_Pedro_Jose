<?php
require_once('../config/connection.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

switch($method){
    case 'GET':
        if(!isset($_GET['id'])){
            $id = intval($_GET['id']);
            $stmt = $conn -> prepare("SELECT id, nombre, descripcion FROM categorias WHERE id = ?");
            $stmt -> bind_param("id", $id);
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            //$libros = array();
            if ($resultado -> num_rows > 0){
                $categoria = $resultado -> fetch_assoc();
                echo json_encode($categoria);
            }else{
                echo json_encode(array("mensaje" => "Categoría no encontrada"));
            }
            $stmt -> close();
            $conn -> close();
        }elseif(!isset($_GET['nombre'])){
            $nombre = trim($_GET['nombre']);
            $stmt = $conn -> prepare("SELECT id, nombre, descripcion FROM categorias WHERE nombre LIKE ?");
            $nombre_param = "%$nombre%";
            $stmt -> bind_param("s", $nombre_param);
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            $categorias = array();
            if($resultado -> num_rows > 0){
                while($row = $resultado -> fetch_assoc()){
                    $categorias[] = $row;
                }
                echo json_encode($categorias);
            }else{
                echo json_encode(array("mensaje" => "Categoría no encontrada"));
            }
            $stmt -> close();
            $conn -> close();
        }else{
            $stmt = $conn -> prepare("SELECT id, nombre, descripcion FROM categorias");
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            $categorias = array();
            while($row = $resultado -> fetch_assoc()){
                $categorias[] = $row;
            }
            $respuesta = json_encode($categorias);
            echo $respuesta;
            $stmt -> close();
            $conn -> close();
        }
        break;
}