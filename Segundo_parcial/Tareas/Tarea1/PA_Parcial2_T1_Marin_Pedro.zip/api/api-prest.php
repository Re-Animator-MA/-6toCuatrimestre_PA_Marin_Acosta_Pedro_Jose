<?php
require_once('../config/connection.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

switch($method){
    case 'GET':
        if(!isset($_GET['id'])){
            $id = intval($_GET['id']);
            $stmt = $conn -> prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestsmos WHERE id = ?");
            $stmt -> bind_param("id", $id);
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            //$libros = array();
            if ($resultado -> num_rows > 0){
                $prestamo = $resultado -> fetch_assoc();
                echo json_encode($prestamo);
            }else{
                echo json_encode(array("mensaje" => "prestamo no encontrado"));
            }
            $stmt -> close();
            $conn -> close();
        }elseif(!isset($_GET['nombre'])){
            $nombre = trim($_GET['nombre']);
            $stmt = $conn -> prepare("SELECT usuarios.id, usuarios.nombre, usuarios.apellido, prestamos.fecha_prestamo, prestamos.fecha_devolucion FROM usuarios
            INNER JOIN prestamos ON usuarios.id = prestamos.id_usuario WHERE usuarios.nombre LIKE ?");
            $nombre_param = "%$nombre%";
            $stmt -> bind_param("s", $nombre_param);
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            $prestamos = array();
            if($resultado -> num_rows > 0){
                while($row = $resultado -> fetch_assoc()){
                    $prestamos[] = $row;
                }
                echo json_encode($prestamos);
            }else{
                echo json_encode(array("mensaje" => "prestamo no encontrado"));
            }
            $stmt -> close();
            $conn -> close();
        }elseif(!isset($_GET['estado'])){
            $estado = trim($_GET['estado']);
            $stmt = $conn -> prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos WHERE estado = ?");
            $estado_param = "%$estado%";
            $stmt -> bind_param("s", $estado_param);
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            $prestamos = array();
            if($resultado -> num_rows > 0){
                while($row = $resultado -> fetch_assoc()){
                    $prestamos[] = $row;
                }
                echo json_encode($prestamos);
            }else{
                echo json_encode(array("mensaje" => "prestamo no encontrado"));
            }
            $stmt -> close();
            $conn -> close();
        }else{
            $stmt = $conn -> prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos");
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            $prestamos = array();
            while($row = $resultado -> fetch_assoc()){
                $prestamos[] = $row;
            }
            $respuesta = json_encode($prestamos);
            echo $respuesta;
            $stmt -> close();
            $conn -> close();
        }
        break;
}