<?php
require_once('../config/connection.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

switch($method){
    case 'GET':
        if(!isset($_GET['disponibles'])){
            $disponible = intval($_GET['disponibles']);
            $stmt = $conn -> prepare("SELECT id, titulo, isbn, anio_publicacion, editorial, cantidad, disponibles, id_categoria, fecha_regidstro FROM libros WHERE diponibles LIKE ?");
            $disponible_param = "%$disponible%";
            $stmt -> bind_param("i", $disponible_param);
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            $disponibles = array();
            if($resultado -> num_rows > 0){
                while($row = $resultado -> fetch_assoc()){
                    $disponibles[] = $row;
                }
                echo json_encode($disponibles);
            }else{
                echo json_encode(array("mensaje" => "No disponible"));
            }
            $stmt -> close();
            $conn -> close();
        }
}   