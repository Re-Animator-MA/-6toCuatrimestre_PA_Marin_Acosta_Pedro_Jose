<?php 
require_once('../config/connection.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

switch($method){
    case 'GET':
        if(!isset($_GET['id'])){//http://localhost/gestor_bibliotecario/api/api-lib.php?id=1
            $id = intval($_GET['id']);
            $stmt = $conn -> prepare("SELECT id, titulo, anio_publicacion, from libros WHERE titulo LIKE = ?");
            $stmt -> bind_param("id", $id);
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            //$libros = array();
            if ($resultado -> num_rows > 0){
                $libros = $resultado -> fetch_assoc();
                echo json_encode($libros);
            }else{
                echo json_encode(array("mensaje" => "Libro no encontrado"));
            }
            $stmt -> close();
            $conn -> close();
        }elseif(!isset($_GET['anio_publicacion'])){//http://localhost/gestor_bibliotecario/api/api-lib.php?titulo="clean code"
            $publicacion = trim($_GET['anio_publicacion']);
            $stmt = $conn -> prepare("SELECT titulo, anio_publicacion, from libros WHERE titulo LIKE ?");
            $publicacion_param = "%$publicacion%";
            $stmt -> bind_param("s", $publicacion_param);
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            $publicacion = array();
            if($resultado -> num_rows > 0){
                while($row = $resultado -> fetch_assoc()){
                    $publicacion[] = $row;
                }
                echo json_encode($publicacion);
            }else{
                echo json_encode(array("mensaje" => "Libro no encontrado"));
            }
            $stmt -> close();
            $conn -> close();
        }else{//http://localhost/gestor_bibliotecario/api/api-lib.php
            $stmt = $conn -> prepare("SELECT categorias.id, libros.titulo, categorias.descripcion, libros.anio_publicacion, FROM libros 
            INNER JOIN categorias ON libros.id_categoria = categorias.id ");
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            $categorias = array();
            while($row = $resultado -> fetch_assoc()){
                $categorias[] = $row;
            }
            $respuesta = json_encode($categorias);
            echo $respuesta;
            $stmt -> close();
            $conn -> close();
        }
        break;
    case 'POST': //http://localhost/gestor_bibliotecario/api/api-lib.php
        $data = json_decode(file_get_contents("php://input"), true);
        $titulo = trim($data["titulo"]?? "");
        $publicacion = trim($data["publicacion"]?? "");
        if(!empty($titulo) && !empty($publicacion)){
            $stmt = $conn -> prepare("INSERT INTO libros (titulo, anio_publicacion) VALUES(?, ?)");
            $stmt -> bind_param("ss", $titulo, $publicacion);
            if($stmt->execute()){
                http_response_code(201);
                echo json_encode(array("mensaje" => "libro creado con exito"));
            }else{
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al crear libro". $stmt->error));
            }
        }else{
            http_response_code(400);
            echo json_encode(array("mensaje" => "El titulo y la fecha de pucblicacion son obligatorios"));
        }
        break;
    case 'PUT': //http://localhost/gestor_bibliotecario/api/api-lib.php?id=1
        if(!isset($_GET['id'])){
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);
            $titulo = trim($data['tiulo']?? "");
            $publicacion = trim($data['publicacion']?? "");
            if(!empty($titulo)){
                $stmt = $conn -> prepare("UPDATE libros SET titulo = ?, anio_publicacion = ?, WHERE id = ?");
                $stmt -> bind_param("ssi", $titulo, $publicacion, $id);
                if($stmt->execute()){
                    http_response_code(200); 
                    echo json_encode(array("mensaje" => "Libro actualizado exitosamente"));
                }else{
                    http_response_code(500); 
                    echo json_encode(array("mensaje" => "Error al actualizar el libro " . $stmt->error));
                }
            }else{
                http_response_code(400);
                echo json_encode(array("mensaje" => "El Titulo es obligatorio"));
            }
        }
        break;
    case 'PATCH':
        if(!isset($_GET['id'])){
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);
            $titulo = trim($data['tiulo']?? "");
            $publicacion = trim($data['publicacion']?? "");
            if(!empty($titulo) || !empty($publicacion)){
                $stmt = $conn -> prepare("UPDATE libros SET titulo = COALESCE(NULLIF(?, ''), anio_publicacion = COALESCE(NULLIF(?, ''), WHERE id = ?");
                $stmt -> bind_param("ssi", $titulo, $publicacion, $id);
                if($stmt->execute()){
                    http_response_code(200); 
                    echo json_encode(array("mensaje" => "Libro actualizado exitosamente"));
                }else{
                    http_response_code(500); 
                    echo json_encode(array("mensaje" => "Error al actualizar el libro " . $stmt->error));
                }
            }else{
                http_response_code(400);
                echo json_encode(array("mensaje" => "El Titulo es obligatorio"));
            }
        }
        break;
    case 'DELETE': //http://localhost/gestor_bibliotecario/api/api-lib.php?id=1
        if(!isset($_GET['id'])){
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("DELETE FROM libros WHERW id = ?");
            $stmt->bind_param("i", $id);
            if($stmt->execute()){
                http_response_code(200);
                echo json_encode(array("mensaje" => "Libro eliminado exitosamente"));
            }else{
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al eliminar Lobro"));
            }
        }else{
            http_response_code(500);
            echo json_encode(array("mensaje" => "El id es obligatorio para eliminar el libro"));
        }
        break;
    default:
        //mensaje
        break;
}