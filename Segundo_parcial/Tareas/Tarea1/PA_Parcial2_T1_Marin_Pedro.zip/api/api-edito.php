<?php
require_once('../config/connection.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

switch($method){
    case 'GET':
        if(!isset($_GET['editorial'])){
            $editorial = trim($_GET['editorial']);
            $stmt = $conn -> prepare("SELECT id, titulo, isbn, anio_publicacion, editorial, cantidad, disponibles, id_categoria, fecha_regidstro FROM libros WHERE titulo LIKE ?");
            $editorial_param = "%$editorial%";
            $stmt -> bind_param("s", $editorial_param);
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            $editoriales = array();
            if($resultado -> num_rows > 0){
                while($row = $resultado -> fetch_assoc()){
                    $editoriales[] = $row;
                }
                echo json_encode($editoriales);
            }else{
                echo json_encode(array("mensaje" => "Libro no encontrado por editorial"));
            }
            $stmt -> close();
            $conn -> close();
        }
}        