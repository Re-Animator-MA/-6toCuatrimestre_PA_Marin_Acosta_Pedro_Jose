<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-tags"></i> Categorías</h1>
    <div style="display:flex;gap:12px;align-items:center">
        <input type="text" id="search-input" placeholder="Buscar categoría..."
               style="padding:10px 14px;border:2px solid #e2e8f0;border-radius:8px;font-size:14px;width:260px">
        <a href="create.php" class="btn btn-primary">
            <i class="fas fa-plus"></i> Nueva Categoría
        </a>
    </div>
</div>

<div id="alert-container"></div>

<div class="table-container" id="tabla-categorias">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>

<?php include_once "../includes/footer.php"; ?>
