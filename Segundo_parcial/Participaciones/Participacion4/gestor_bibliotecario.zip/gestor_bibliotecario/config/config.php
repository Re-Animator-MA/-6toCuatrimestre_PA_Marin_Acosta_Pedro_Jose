<?php
    $db_host = "localhost";
    $db_user = "root";
    $db_pass = "phpd474w38";
    $db_name = "gestor_biblioteca";
