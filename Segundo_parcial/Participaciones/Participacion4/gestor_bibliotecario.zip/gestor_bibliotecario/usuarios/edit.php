<?php 
require_once "../config/connection.php";

include_once "../includes/header.php"; 

$id = intval($_GET["id"] ?? 0);

   
    if ($id > 0) {
        $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, password, telefono, id_rol FROM usuarios WHERE id = ? AND activo = 1");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $usuario = $resultado->fetch_assoc();
        $stmt->close();

        if (!$usuario) {
            $conn->close();
            header("Location: index.php?error=" . urlencode("Usuario no encontrado"));
            exit;
        }
        
    } else {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }

    $stmt = $conn->prepare("SELECT id, nombre FROM roles ORDER BY nombre"); 
    $stmt->execute(); 
    $resultado = $stmt->get_result(); 
    $roles = []; 
    while($row = $resultado->fetch_assoc()){ 
        $roles[] = $row; 
    }
    $stmt->close();

    $conn->close();


?>

<div class="page-header">
    <h1><i class="fas fa-user-edit"></i> Editar Usuario</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<?php if (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>

<div class="card">
    <form action="update.php" method="POST">
        <input type="hidden" name="id" value="<?= $usuario["id"] ?? $id ?>">
        <div class="form-group">
            <label><i class="fas fa-user"></i> Nombre</label>
            <input type="text" name="nombre" value="<?= htmlspecialchars($usuario["nombre"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-user"></i> Apellido</label>
            <input type="text" name="apellido" value="<?= htmlspecialchars($usuario["apellido"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-globe"></i> Correo</label>
            <input type="email" name="correo" value="<?= htmlspecialchars($usuario["correo"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-user"></i> Contraseña</label>
            <input type="password" name="password" value="<?= htmlspecialchars($usuario["password"] ?? "") ?>" minlength="6" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-user"></i> Telefono</label>
            <input type="text" name="telefono" value="<?= htmlspecialchars($usuario["telefono"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-tag"></i> Rol</label>
            <select name="id_rol" required>
                <option value="">-- Selecciona un rol --</option>
                <?php
                    
                    foreach($roles as $rol){ 
                        $selected = ((int) $rol['id'] === (int) ($usuario['id_rol'] ?? 0)) ? "selected" : "";
                        echo "<option value='" . htmlspecialchars($rol['id']) . "' $selected>" . htmlspecialchars($rol['nombre']) . "</option>"; 
                    }
                ?>
            </select>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Guardar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>