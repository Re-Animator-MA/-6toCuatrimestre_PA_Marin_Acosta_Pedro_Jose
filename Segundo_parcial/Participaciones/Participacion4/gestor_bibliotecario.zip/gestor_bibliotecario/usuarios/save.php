<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }

    $nombre = trim($_POST["nombre"] ?? "");
    $apellido = trim($_POST["apellido"] ?? "");
    $correo = trim($_POST["correo"] ?? "");
    $password = trim($_POST["password"] ?? "");
    $telefono = trim($_POST["telefono"] ?? "");
    $id_rol = intval($_POST["id_rol"] ?? 0);

    if ($nombre === "" || $apellido === "") {
        header("Location: create.php?error=" . urlencode("El nombre y apellido son obligatorios"));
        exit;
    }

    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        header("Location: create.php?error=" . urlencode("El correo no es válido"));
        exit;
    }

    if (strlen($password) < 6) {
        header("Location: create.php?error=" . urlencode("La contraseña debe tener al menos 6 caracteres"));
        exit;
    }

    if ($id_rol <= 0) {
        header("Location: create.php?error=" . urlencode("El rol es obligatorio"));
        exit;
    }

    // Aquí va el código para crear el usuario usando una consulta preparada
    $stmt = $conn->prepare("INSERT INTO usuarios (nombre, apellido, correo, password, telefono, id_rol) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssi", $nombre, $apellido, $correo, $password, $telefono, $id_rol);

    if ($stmt->execute()) {
        header("Location: index.php?success=" . urlencode("Usuario creado exitosamente"));
        exit;
    } else {
        header("Location: create.php?error=" . urlencode("Error al crear el usuario: " . $stmt->error));
        exit;
    }
    $stmt->close();
    $conn->close();
?>