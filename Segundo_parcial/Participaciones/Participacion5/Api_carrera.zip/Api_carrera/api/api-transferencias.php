<?php
    require_once('..\config\connection.php');

    header("Access-Control-Allow-origin: *");
    header("Content-Type: application/json; charset=utf-8");
    header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    $method = $_SERVER['REQUEST_METHOD'];

    if($method === 'OPTIONS'){
        http_response_code(200);
        echo json_encode(array("mensaje" => "Preflight OK"));
        $conn -> close();
        exit;
    }
    switch($method){
        case 'GET':
            if(isset($_GET['id'])){
                $id = intval($_GET['id']);
                $stmt = $conn -> prepare("SELECT id, jugador_id, equipo_origen_id, equipo_destino_id, monto_pagado, fecha FROM transferencias WHERE id = ?");
                $stmt -> bind_param("i", $id);
                $stmt -> execute();
                $resultado = $stmt -> get_result();
                
                if($resultado -> num_rows > 0){
                    http_response_code(200);
                    echo json_encode($resultado -> fetch_assoc());
                }else{
                    http_response_code(404);
                    echo json_encode(array("mensaje" => "Jugador no encntrado"));
                }
                $stmt -> close();
            }elseif(isset($_GET['jugador_id'])){
                $jugador_id = intval($_GET['jugador_id']);
                $stmt = $conn -> prepare("SELECT id, jugador_id, equipo_origen_id, equipo_destino_id, monto_pagado, fecha FROM transferencias WHERE  jugador_id = ? ORDER BY id");
                $stmt -> bind_param("i", $jugador_id);
                $stmt -> execute();
                $resultado = $stmt -> get_result();
                $jugadores = array();

                while ($row = $resultado -> fetch_assoc()){
                    $jugadores[] = $row;
                }
                http_response_code(200);
                echo json_encode($jugadores);
                $stmt -> close();
            }elseif(isset($_GET['monto_pagado'])){
                $monto_pagado = doubleval($_GET['monto_pagado']);
                $stmt = $conn -> prepare("SELECT id, jugador_id, equipo_origen_id, equipo_destino_id, monto_pagado, fecha FROM transferencias WHERE monto_pagado = ? ");
                $stmt -> bind_param("d", $monto_pagado);
                $stmt -> execute();
                $resultado = $stmt -> get_result();
                $montos = array();

                while ($row = $resultado -> fetch_assoc()){
                    $montos[] = $row;
                }
                http_response_code(200);
                echo json_encode($montos);
                $stmt -> close();
            }else{
                $stmt = $conn->prepare("SELECT id, jugador_id, equipo_origen_id, equipo_destino_id, monto_pagado, fecha FROM transferencias ORDER BY id");
                $stmt->execute();
                $resultado = $stmt->get_result();
                $transferencias = array();

                while ($row = $resultado->fetch_assoc()) {
                    $transferencias[] = $row;
                }
                http_response_code(200);
                echo json_encode($transferencias);
                $stmt->close();
            }
            $conn -> close();
            break;
        default:
        http_response_code(404);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
    }