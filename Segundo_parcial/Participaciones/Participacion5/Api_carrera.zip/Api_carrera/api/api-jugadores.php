<?php
    require_once('..\config\connection.php');

    header("Access-Control-Allow-origin: *");
    header("Content-Type: application/json; charset=utf-8");
    header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    $method = $_SERVER['REQUEST_METHOD'];

    if($method === 'OPTIONS'){
        http_response_code(200);
        echo json_encode(array("mensaje" => "Preflight OK"));
        $conn -> close();
        exit;
    }
    switch($method){
        case 'GET':
            if(isset($_GET['id'])){
                $id = intval($_GET['id']);
                $stmt = $conn -> prepare("SELECT id, nombre, posicion, valor_mercado, media_global, equipo_id FROM jugadores WHERE id = ?");
                $stmt -> bind_param("i", $id);
                $stmt -> execute();
                $resultado = $stmt -> get_result();
                
                if($resultado -> num_rows > 0){
                    http_response_code(200);
                    echo json_encode($resultado -> fetch_assoc());
                }else{
                    http_response_code(404);
                    echo json_encode(array("mensaje" => "Jugador no encntrado"));
                }
                $stmt -> close();
            }elseif(isset($_GET['nombre'])){
                $nombre = trim($_GET['nombre']);
                $nombre_param = "%$nombre%";
                $stmt = $conn -> prepare("SELECT id, nombre, posicion, valor_mercado, media_global, equipo_id FROM jugadores WHERE nombre LIKE ?");
                $stmt -> bind_param("s", $nombre_param);
                $stmt -> execute();
                $resultado = $stmt -> get_result();
                $jugadores = array();
                if($resultado->num_rows > 0){
                    while ($row = $resultado -> fetch_assoc()){
                        $jugadores[] = $row;
                    }
                    http_response_code(200);
                    echo json_encode($jugadores);
                }else{
                    echo json_encode(array("mensaje" => "Jugador no encntrado"));
                } 
                $stmt -> close();
            }elseif(isset($_GET['posicion'])){
                $posicion = trim($_GET['posicion']);
                $posicion_param = "%$posicion%";
                $stmt = $conn -> prepare("SELECT id, nombre, posicion, valor_mercado, media_global, equipo_id FROM jugadores  WHERE posicion LIKE ?");
                $stmt -> bind_param("s", $posicion_param);
                $stmt -> execute();
                $resultado = $stmt -> get_result();
                $posiciones = array();

                while ($row = $resultado -> fetch_assoc()){
                    $posiciones[] = $row;
                }
                http_response_code(200);
                echo json_encode($posiciones);
                $stmt -> close();
            }else{
                $stmt = $conn->prepare("SELECT id, nombre, posicion, valor_mercado, media_global, equipo_id FROM jugadores ORDER BY id");
                $stmt->execute();
                $resultado = $stmt->get_result();
                $jugadores = array();

                while ($row = $resultado->fetch_assoc()) {
                    $jugadores[] = $row;
                }
                http_response_code(200);
                echo json_encode($jugadores);
                $stmt->close();
            }
            $conn -> close();
            break;
        default:
        http_response_code(404);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
    }