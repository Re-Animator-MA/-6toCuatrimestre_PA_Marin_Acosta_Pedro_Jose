<?php
    //require_once('C:\xampp\htdocs\Api_carrera\config\connetion.php');
    require_once('..\config\connection.php');

    header("Access-Control-Allow-origin: *");
    header("Content-Type: application/json; charset=utf-8");
    header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    $method = $_SERVER['REQUEST_METHOD'];

    if($method === 'OPTIONS'){
        http_response_code(200);
        echo json_encode(array("mensaje" => "Preflight OK"));
        $conn -> close();
        exit;
    }
    switch($method){
        case 'GET':
            if(isset($_GET['id'])){
                $id = intval($_GET['id']);
                $stmt = $conn -> prepare("SELECT id, nombre, liga, presupuesto, creado_en FROM equipos WHERE id = ?");
                $stmt -> bind_param("i", $id);
                $stmt -> execute();
                $resultado = $stmt -> get_result();
                
                if($resultado -> num_rows > 0){
                    http_response_code(200);
                    echo json_encode($resultado -> fetch_assoc());
                }else{
                    http_response_code(404);
                    echo json_encode(array("mensaje" => "Equipo no encntrado"));
                }
                $stmt -> close();
            }elseif(isset($_GET['nombre'])){
                $nombre = trim($_GET['nombre']);
                $nombre_param = "%$nombre%";
                $stmt = $conn -> prepare("SELECT id, nombre, liga, presupuesto, creado_en FROM equipos WHERE nombre LIKE ?");
                $stmt -> bind_param("s", $nombre_param);
                $stmt -> execute();
                $resultado = $stmt -> get_result();
                $nombres = array();
                if($resultado->num_rows > 0){
                    while ($row = $resultado -> fetch_assoc()){
                        $nombres[] = $row;
                    }
                    http_response_code(200);
                    echo json_encode($nombres);
                }else{
                    echo json_encode(array("mensaje" => "Equipo no encntrado"));
                }
                $stmt -> close();
            }elseif(isset($_GET['liga'])){
                $liga = trim($_GET['liga']);
                $liga_param = "%$liga%";
                $stmt = $conn -> prepare("SELECT id, nombre, liga, presupuesto, creado_en FROM equipos WHERE liga LIKE ? ORDER BY id");
                $stmt -> bind_param("s", $liga_param);
                $stmt -> execute();
                $resultado = $stmt -> get_result();
                $ligas = array();

                while ($row = $resultado -> fetch_assoc()){
                    $ligas[] = $row;
                }
                http_response_code(200);
                echo json_encode($ligas);
                $stmt -> close();
            }else{
                $stmt = $conn->prepare("SELECT id, nombre, liga, presupuesto, creado_en FROM equipos ORDER BY id");
                $stmt->execute();
                $resultado = $stmt->get_result();
                $equipos = array();

                while ($row = $resultado->fetch_assoc()) {
                    $equipos[] = $row;
                }
                http_response_code(200);
                echo json_encode($equipos);
                $stmt->close();
            }
            $conn -> close();
            break;
        default:
        http_response_code(404);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
    }