<?php 
    require_once __DIR__ . "/data_db.php";

    $conn = new mysqli(...$datos);
    if($conn -> connect_error){
        die("connection failed" . $conn -> connect_error);
    }
    $conn -> set_charset("utf8");