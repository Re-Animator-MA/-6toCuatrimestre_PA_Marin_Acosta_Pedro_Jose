<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <title>Examen Parcial 2</title>
</head>
<body>
    <div class="page-header">
        <h2><i class="fas fa-user-graduate"></i> Gestor</h2>
        <p>Gestión de alumnos</p>
    <h1><i class="fas fa-users"></i> Alumnos</h1>
    <div style="display:flex;gap:12px;align-items:center">
        <input type="text" id="search-input" placeholder="Buscar Alumno..."
            style="padding:10px 14px;border:2px solid #e2e8f0;border-radius:8px;font-size:14px;width:260px">
    </div><br>
</div>
<div id="alert-container"></div>
<div class="card">
    <form id="alumno-create-form">
        <div class="form-group">
            <label><i class="fas fa-tag"></i> Matricula </label><br>
            <input type="text" id="matricula" name="matricula">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-user"></i> Nombre </label><br>
            <input type="text" id="nombre" name="nombre">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-user"></i> Apellido Paterno </label><br>
            <input type="text" id="apellido_paterno" name="apellido_paterno">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-user"></i> Apellido Materno </label><br>
            <input type="text" id="apellido_materno" name="apellido_materno">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-envelope"></i> Correo </label><br>
            <input type="text" id="correo" name="correo">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-phone"></i> Telefono </label><br>
            <input type="text" id="telefono" name="telefono">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-calendar"></i> Fecha de Nacimiento </label><br>
            <input type="datetime-local" id="fecha_nacimiento" name="fecha_nacimiento">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-align-left"></i> Id Carrera </label><br>
            <input type="text" id="id_carrera" name="id_carrera">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-align-left"></i> Cuatrimestre Actual </label><br>
            <input type="text" id="cuatrimestre_actual" name="cuatrimestre_actual">
        </div>
        <br>
        <div class="form-group">
            <label><i class="fas fa-tag"></i> Estatus </label><br>
            <input type="text" id="estatus" name="estatus">
        </div>
        <br>
        <div class="form-actions">
            <button type="submit" class="btn btn-success" id="guardar-alumno-btn">
                <i class="fas fa-save"></i> Guardar
            </button>
            <a href="views/alumnos.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<div class="table-container" id="tabla-alumnos">
    <table style="font-size:small;">
        <thead>
            <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Email</th>
                <th>Telefono</th>
                <th>Fecha de Nacimiento</th>
                <th>Activo</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
<div>
     <?php
        $scriptFile = __DIR__ . 'assets/js/Alumnos-Script.js';
        $scriptVersion = file_exists($scriptFile) ? filemtime($scriptFile) : time();
    ?>
    <script src="<?= htmlspecialchars($basePath ?? '') ?>assets/js/Alumnos-Scripts.js?v=<?= $scriptVersion ?>"></script>
</div>
</body>
</html>