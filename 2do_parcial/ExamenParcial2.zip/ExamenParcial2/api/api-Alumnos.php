<?php
require_once "../config/Conexion.php";

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id_alumno, nombre, apellido, email, telefono, fecha_nacimiento, activo FROM alumnos WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                $alumno = $resultado->fetch_assoc();
                http_response_code(200);
                echo json_encode([$alumno], JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "alumno no encontrado"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        } elseif (isset($_GET['todas']) && strtolower(trim($_GET['todas'])) === 'true') {
            $stmt = $conn->prepare("SELECT id_alumno, nombre, apellido, email, telefono, fecha_nacimiento, activo FROM alumnos ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $alumnos = array();
            while ($row = $resultado->fetch_assoc()) {
                $alumnos[] = $row;
            }
            http_response_code(200);
            echo json_encode($alumnos, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        } elseif (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $stmt = $conn->prepare("SELECT id_alumno, nombre, apellido, email, telefono, fecha_nacimiento, activo FROM alumnos WHERE nombre LIKE ?");
            $nombre_param = "%$nombre%";
            $stmt->bind_param("s", $nombre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $alumnos = array();
            if ($resultado->num_rows > 0) {
                while ($row = $resultado->fetch_assoc()) {
                    $alumnos[] = $row;
                }
                http_response_code(200);
                echo json_encode($alumnos, JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Alumno no encontrado"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        }elseif(isset($_GET['apellido'])){
            $apellido = trim($_GET['apellido']);
            $stmt = $conn->prepare("SELECT id_alumno, nombre, apellido, email, telefono, fecha_nacimiento, activo FROM alumnos WHERE apellido LIKE ?");
            $apellido_param = "%$apellido%";
            $stmt->bind_param("s", $apellido_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $alumnos = array();
            if ($resultado->num_rows > 0) {
                while ($row = $resultado->fetch_assoc()) {
                    $alumnos[] = $row;
                }
                http_response_code(200);
                echo json_encode($alumnos, JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Alumno no encontrado"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        } else {
            $stmt = $conn->prepare("SELECT id_alumno, nombre, apellido, email, telefono, fecha_nacimiento, activo FROM alumnos ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $alumnos = array();
            while ($row = $resultado->fetch_assoc()) {
                $alumnos[] = $row;
            }
            http_response_code(200);
            echo json_encode($alumnos, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        }
        //$conn -> close();
        break;
    
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $nombre = trim($data['nombre'] ?? "");
        $apellido = trim($data['apellido'] ?? "");
        $email = trim($data['email'] ?? "");
        $telefono = trim($data['telefono'] ?? "");
        $fecha_nacimiento = trim($data['fecha_nacimiento'] ?? "");
        $activo = trim($data['activo'] ?? "");
        if (!empty($nombre) && !empty($apellido) && !empty($email)) {
            $stmt = $conn->prepare("INSERT INTO alumnos (nombre, apellido, email, telefono, fecha_nacimiento, activo) 
            VALUES (?, ?, ?, ?, ?, ? )");
            $stmt->bind_param(
                "ssssdi",$nombre, $apellido_,$email, $telefono, $fecha_nacimiento, $activo);
            if ($stmt->execute()) {
                http_response_code(201);
                echo json_encode(array("mensaje" => "Alumno añadido exitosamente"), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al añadir al alumno: " . $stmt->error), JSON_UNESCAPED_UNICODE);
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El nombre completo es obligatorio"), JSON_UNESCAPED_UNICODE);
        }
        break;  
    case 'PUT':
        if (isset($_GET['id'])) {
            $id_alumno = intval($_GET['id']);
            $nombre = trim($data['nombre'] ?? "");
            $apellido = trim($data['apellido'] ?? "");
            $email = trim($data['email'] ?? "");
            $telefono = trim($data['telefono'] ?? "");
            $fecha_nacimiento = trim($data['fecha_nacimiento'] ?? "");
            $activo = trim($data['activo'] ?? "");
            if (!empty($nombre) && !empty($apellido_paterno) && !empty($apellido_materno)) {
                    $stmt = $conn->prepare("UPDATE alumnos SET 
                    nombre = ?, 
                    apellido = ?,
                    email = ?,
                    telefono = ?,
                    fecha_nacimiento = ?,
                    activo = ?
                    WHERE id = ?");
                $stmt->bind_param(
                    "ssssdi",$nombre, $apellido_,$email, $telefono, $fecha_nacimiento, $activo);
                if ($stmt->execute()) {
                    http_response_code(200);
                    echo json_encode(array("mensaje" => "Alumno actualizado exitosamente"), JSON_UNESCAPED_UNICODE);
                } else {
                    http_response_code(500);
                    echo json_encode(array("mensaje" => "Error al actualizar Alumno: " . $stmt->error), JSON_UNESCAPED_UNICODE);
                }
            } else {
                http_response_code(400);
                echo json_encode(array("mensaje" => "El nombre completo es obligatorio"), JSON_UNESCAPED_UNICODE);
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar a un alumno"), JSON_UNESCAPED_UNICODE);
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Método no permitido"), JSON_UNESCAPED_UNICODE);
        break;
}