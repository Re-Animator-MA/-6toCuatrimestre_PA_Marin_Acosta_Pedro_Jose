const URL_BASE = 'http://localhost/ExamenParcial2/api/';

// GET ../api/api-Alumnos.php — listar todos
async function getAlumnos() {
    const tbody = document.querySelector('#tabla-Alumnos tbody');
    if (!tbody) {
        return;
    }
    try {
        const response = await fetch(`${URL_BASE}api-Alumnos.php`);
        const data = await response.json();
        console.log("Respuesta de la API:", data);
        tbody.innerHTML = '';
        data.forEach(alumno => {
            console.log("Pintando alumno:", alumno); 
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${alumno.id_alumno}</td>
                <td>${alumno.nombre}</td>
                <td>${alumno.apellido}</td>
                <td>${alumno.email}</td>
                <td>${alumno.telefono}</td>
                <td>${alumno.fecha_nacimiento}</td>
                <td>${alumno.activo}</td>
                <td>
                    <button class="button_warning" onclick="redirigirEditarAlumnos(${alumno.id})">
                        <i class="fas fa-edit"></i>Editar
                    </button>
                    <button class="button_danger" onclick="eliminarDatoAlumno(${alumno.id})">
                        <i class="fas fa-trash"></i>Eliminar
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        })
    } catch (error) {
        console.error('Error al obtener los alumnos: ', error);
    }
}
// POST ../api/api-Alumnos.php — registrar
async function registrarAlumno(nombre, apellido, email, telefono, fecha_nacimiento, activo ) {
    try {
        const nuevoAlumno = {
            nombre,
            apellido_,
            email,
            telefono,
            fecha_nacimiento,
            activo
        };
        const response = await fetch(`${URL_BASE}api-Alumnos.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(nuevoAlumno)
        })
        if (response.ok) {
            window.location.replace('index.php'); 
            return;
        } else {
            const errorData = await response.json().catch(() => null);
            const mensaje = errorData?.mensaje || response.statusText || 'Error al registrar al alumno';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al registrar al alumno: ', error);
    }
}
// PUT ../api/api-Alumnos.php?id=1 — actualizar completa 
async function actualizarAlumno(nombre, apellido, email, telefono, fecha_nacimiento, activo) {
    const alumnoActualizado = {
        nombre,
        apellido_,
        email,
        telefono,
        fecha_nacimiento,
        activo
    }
    try {
        const response = await fetch(`${URL_BASE}api-Alumnos.php?id=${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(alumnoActualizado)
        })
        if (response.ok) {
            window.location.replace('index.php');
            return;
        } else {
            const errorData = await response.json().catch(() => null); 
            const mensaje = errorData?.mensaje || response.statusText || 'Error al actualizar al alumno';
            console.log(mensaje);
        }
    } catch (error) {
        console.error('Error al actualizar al alumno: ', error);
    }
}

async function eventoRegistrarAlumno() {
    event.preventDefault();
    const nombre = document.getElementById('nombre').value.trim();
    const apellido  = document.getElementById('apellido').value.trim();
    const email  = document.getElementById('email').value.trim();
    const telefono  = document.getElementById('telefono').value.trim();
    const fecha_nacimiento  = document.getElementById('fecha_nacimiento').value.trim();
    const activo  = document.getElementById('activo').value.trim(); 
    if (!nombre || !apellido || !email) {
        console.log('El nombre completo es obligatorio con el email ');
        return;
    }
    
    await registrarAlumno(
        nombre,
        apellido,
        email,
        telefono,
        fecha_nacimiento,
        activo
    );
}
document.addEventListener('DOMContentLoaded', () => {
    getAlumnos();

const searchInput = document.getElementById('search-input');
    if(searchInput){
        searchInput.addEventListener('input', (event) => {
            const valor = event.target.value.trim();
            if(valor){
                getAlumnoPorId(valor);
                buscarAlumnosPorMatricula(valor);
                buscarAlumnosPorNombre(valor);
                buscarAlumnosPorCarrera(valor);
            }else{
                getAlumnos();
            }
        });
    }
});