<?php
    require_once __DIR__. "/DB.php";
    $conn = new mysqli(...$datos);
    if($conn -> connect_error){
        die("Conection failed: ". $conn -> connect_error);
    }
    $conn -> set_charset("utf8");
?>