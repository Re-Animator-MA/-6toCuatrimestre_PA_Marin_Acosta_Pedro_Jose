<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: libros/index.php");
        exit;
    }

    $id               = intval($_POST["id"] ?? 0);
    $nombre           = trim($_POST["nombre"] ?? "");
    $apellido         = trim($_POST["apellido"] ?? "");
    $nacionalidad     = trim($_POST["nacionalidad"] ?? "");
    $fecha_nacimiento = trim($_POST["fecha_nacimiento"] ?? "") ?: null;

    $stmt = $conn -> prepare("UPDATE autores SET nombre = ?, apellido = ?, nacionalidad = ?, feha_nacimiento = ? WHERE id = ?");
    $stmt -> bind_param("ssssi", $nombre, $apellido, $nacionalidad, $fecha_nacimiento, $id);
    if ($id <= 0 || $nombre === "" || $apellido === "") {
        header("Location: autores/index.php?error=" . urlencode("Datos inválidos") . $stmt -> error);
    }else{
        header("Location: autores/index.php?success=" . urlencode("Autores actualizados exitosamente"));
    }
    $stmt -> close();
    $conn -> close();
    exit();

    // Aquí va el código para actualizar el autor usando una consulta preparada
?>
