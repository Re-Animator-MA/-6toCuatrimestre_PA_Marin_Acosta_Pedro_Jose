<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: autores/index.php");
        exit;
    }

    $nombre           = trim($_POST["nombre"] ?? "");
    $apellido         = trim($_POST["apellido"] ?? "");
    $nacionalidad     = trim($_POST["nacionalidad"] ?? "");
    $fecha_nacimiento = trim($_POST["fecha_nacimiento"] ?? "") ?: null;

    if ($nombre === "" || $apellido === "") {
        header("Location: autores/create.php?error=" . urlencode("El nombre y apellido son obligatorios"));
        exit;
    }
    $stmt = $conn -> prepare("INSERT INTO autores(nombre, apellido, nacionalidad, fecha_nacimiento) VALUES (?, ?, ?, ?)");
    $stmt -> bind_param("ssss", $nombre, $apellido, $nacionalidad, $fecha_nacimiento);
    // Aquí va el código para crear el autor usando una consulta preparada
    if($stmt -> execute()){
        header("Location: autores/index.php?success=" . urlencode("Autor añadido exitosamente"));
    }else{
        header("Location: autores/create.php?error=" . urlencode("Error al añadir el autor: " . $stmt -> error));
    }
    $stmt -> close();
    $conn -> close();
    exit;
?>
