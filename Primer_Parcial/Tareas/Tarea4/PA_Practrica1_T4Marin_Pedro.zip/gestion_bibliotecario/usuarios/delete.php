<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);
    
    if($id <= 0){
        header("Location: usuarios/index.php?error=". urlencode("ID invalido"));
        exit;
    }

    $stmt = $conn -> prepare("DELETE FROM usuarios WHERE id = ? ");
    $stmt -> bind_param("i", $id);
    if($stmt -> execute()){
        header("Location: usuarios/index.php?error=". urlencode("Usuario eliminado con exito."));
    }else{
        header("Location: usuarios/index.php?error=". urlencode("Error al eliminar al usuario."));
    }
    $stmt -> close();
    $conn -> close();
    exit();
?>