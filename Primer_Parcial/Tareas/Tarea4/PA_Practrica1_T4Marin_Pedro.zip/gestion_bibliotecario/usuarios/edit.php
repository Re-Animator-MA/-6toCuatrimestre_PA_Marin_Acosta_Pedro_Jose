<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);

    if($id > 0){
        $stmt = $conn -> prepare("SELECT 
        id, 
        nombre,
        apellido, 
        correo, 
        password,
        telefono, 
        id_rol,
        activo,
        fecha_registro FROM usuarios WHERE id = ? ");
        $stmt -> bind_param("i", $id);
        $stmt -> execute();
        $resultado = $stmt -> get_result();
        $uasuario = $resultado -> fetch_assoc();
        $stmt -> close();

        $stmt = $conn -> prepare("SELECT id, nombre FROM roles");
        $stmt -> execute();
        $resultado2 = $stmt -> get_result();
        $roles =[];
        while($fila = $resultado2 -> fetch_assoc()){
            $roles[] = $fila;
        }
        //$roles = $resultado2 -> fetch_assoc();
        $stmt -> close();
        $conn -> close();
    }else{
        header("Location: usuarios/index.php?error=" . urlencode("ID inválido"));
        $conn -> close();
        exit;
    }
?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-book-open"></i> Editar Usuario</h1>
    <a href="usuarios/index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>
<div class="card">
    <form action="usuarios/update.php" method="POST">
        <input type="hidden" name="id" value="<?= $usuario["id"] ?? $id ?>">

        <div class="form-group">
            <label><i class="fas fa-user"></i>Nombre</label>
            <input type="text" name="nombre" value="<?= htmlspecialchars($usuario["nombre"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-user"></i>Apellido</label>
            <input type="text" name="apellido" value="<?= htmlspecialchars($usuario["apellido"] ?? "") ?>" required>
        </div>
        <div class="form-group">
            <label><i class="fas fa-envelope"></i> Correo</label>
            <input type="text" name="correo" value="<?= htmlspecialchars($usuario["correo"] ?? "") ?>">
        </div>
            
        <div class="form-group">
            <label><i class="fas fa-solid fa-lock"></i> Paswword</label>
            <input type="password" name="password" value="<?= htmlspecialchars($usuario["password"] ?? "") ?>">
        </div>

        <div class="form-group">
            <label><i class="fas fa-solid fa-phone"></i> Telefono</label>
            <input type="text" name="nombre" value="<?= htmlspecialchars($usuario["telefono"] ?? "") ?>">
        </div>
            
        <div class="form-group">
            <label><i class="fas fa-solid fa-user-gear"></i> Rol</label>
            <select name="id_rol" required>
                <option value="">-- Selecciona un Rol --</option>
                    <?php 
                    foreach($roles as $rol){
                        echo "<option value='{$rol['id']}'>{$rol['nombre']}</option>";
                    }   
                    ?>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-solid fa-user-gear"></i> Activo</label>
            <input type="text" name="acrivo" value="<?= htmlspecialchars($usuario["activo"] ?? "") ?>">
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar"></i> Fecha de Registro</label>
            <input type="date" name="fecha_registro" value="<?= htmlspecialchars($usuario["fecha_registro"] ?? "") ?>">
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Actualizar
            </button>
            <a href="usuarios/index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>
<?php include_once "../includes/footer.php"; ?>