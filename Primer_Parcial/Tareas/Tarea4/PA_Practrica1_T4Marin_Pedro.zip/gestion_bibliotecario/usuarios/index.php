<?php
    require_once "../config/connection.php";
?>
<?php
    include_once "../includes/header.php";
?>
<div class="page-header">
    <h1><i class = "fas fa-users"></i> Usuarios</h1>
    <a href = "usuarios/create.php" class="btn btn-primary">
        <i class = "fas fa-plus"></i> Nuevo usuario
    </a>
</div>
<?php 
    if (isset($_GET["success"])): ?>
    <div class = "alert alert-success">
        <i class = "fas fa-check-circle"></i>
        <?= htmlspecialchars($_GET["success"]) ?>
    </div>
<?php 
    elseif (isset($_GET["error"])): ?>
    <div class = "alert alert-danger">
        <i class = "fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php 
endif; 
?>
<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Correo</th>
                <th>Password</th>
                <th>Telefono</th>
                <th>Rol</th>
                <th>Activo</th>
                <th>Fecha de Registro</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $stmt = $conn -> prepare("SELECT 
            usuarios.id, 
            usuarios.nombre, 
            usuarios.apellido, 
            usuarios.correo,
            usuarios.password,
            usuarios.telefono,
            roles.nombre,
            usuarios.activo,
            usuarios.fecha_registro 
            FROM usuarios INNER JOIN roles ON usuarios.id_rol = roles.id");
            $stmt -> execute();
            $resultado = $stmt -> get_result();
            while($row = $resultado -> fetch_assoc()){
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["nombre"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["apellido"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["correo"]) . "</td>"; 
                echo "<td>" . htmlspecialchars($row["password"]) . "</td>"; 
                echo "<td>" . htmlspecialchars($row["telefono"]) . "</td>"; 
                echo "<td>" . htmlspecialchars($row["nombre"]) . "</td>"; 
                echo "<td>" . htmlspecialchars($row["activo"]) . "</td>"; 
                echo "<td>" . htmlspecialchars($row["fecha_registro"]) . "</td>"; 
                echo "<td>"; 
                echo "<a href='usuarios/edit.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-warning'><i class='fas fa-edit'></i>Editar</a><br><br>"; 
                echo "<a href='usuarios/delete.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-danger'><i class='fas fa-trash'></i> Eliminar</a>"; 
                echo "</td>"; 
                echo "</tr>"; 
            }
            $stmt -> close();
            $conn -> close();
            ?>
        </tbody>
    </table>
</div>
<?php include_once "../includes/footer.php"; ?>