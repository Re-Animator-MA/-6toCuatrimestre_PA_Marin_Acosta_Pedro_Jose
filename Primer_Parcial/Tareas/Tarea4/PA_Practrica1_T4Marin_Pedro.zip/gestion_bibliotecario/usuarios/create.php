<?php 
require_once "../config/connection.php";
/*$stmt = $conn -> prepare("SELECT 
            usuarios.id, 
            usuarios.nombre, 
            usuarios.apellido, 
            usuarios.correo,
            usuarios.password,
            usuarios.telefono,
            roles.nombre,
            usuarios.activo,
            usuarios.fecha_registro 
            FROM usuarios INNER JOIN roles ON usuarios.id_rol = roles.id");
$stmt -> execute();
$resultado_usuarios = $stmt -> get_result();
$usuarios = [];
while($row = $resultado_usuarios -> fetch_assoc()){
    $usuarios = $row;
}
$stmt -> close();*/

$stmt = $conn -> prepare("SELECT id, nombre FROM roles");
$stmt -> execute();
$resultado_roles = $stmt -> get_result();
$roles = [];
while($row = $resultado_roles -> fetch_assoc()){
    $roles[] = $row;
}
$stmt -> close();
?>
<?php include_once "../includes/header.php"; ?>
<div class="page-header">
    <h1><i class="fas fa-user-plus"></i>Nuevo Usuario</h1>
    <a href="usuarios/index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i>Volver
    </a>
    
</div>

<div class="card">
    <form action="usuarios/save.php" method="POST">
        <div class="form-group">
            <label><i class="fas fa-user"></i>Nombre</label>
            <input type="text" name="nombre" placeholder="Ej: Perico" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-user"></i>Apellido</label>
            <input type="text" name="apellido" placeholder="Ej: Malvado" required>
        </div>
        <div class="form-group">
            <label><i class="fas fa-envelope"></i> Correo</label>
            <input type="text" name="correo" placeholder="Ej: **@email.com">
        </div>
            
        <div class="form-group">
            <label><i class="fas fa-solid fa-lock"></i> Paswword</label>
            <input type="password" name="password" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-solid fa-phone"></i> Telefono</label>
            <input type="text" name="telefono" required>
        </div>
            
        <div class="form-group">
            <label><i class="fas fa-solid fa-user-gear"></i> Rol</label>
            <select name="id_rol" required>
                <option value="">-- Selecciona un Rol --</option>
                <?php 
                foreach($roles as $rol){
                     echo "<option value='{$rol['id']}'>{$rol['nombre']}</option>"; 
                }   
                ?>
            </select>
            
        </div>

        <div class="form-group">
            <label><i class="fas fa-solid fa-user-gear"></i> Activo</label>
            <input type="text" name="acrivo">
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar"></i> Fecha de Registro</label>
            <input type="date" name="fecha_registro">
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Guardar
            </button>
            <a href="usuarios/index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>
<?php include_once "../includes/footer.php"; ?>