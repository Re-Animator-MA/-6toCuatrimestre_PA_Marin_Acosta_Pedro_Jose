<?php 
    require_once "../config/connection.php";

     if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: usuarios/index.php");
        exit;
    }
    $id = intval($_POST["id"] ?? 0);
    $nombre = trim($_POST["nombre"] ?? "");
    $apellido = trim($_POST["apellido"]?? "");
    $correo = trim($_POST["correo"]?? "") ?: null;
    $password = trim($_POST["password"] ?? "");
    $telefono = trim($_POST["telefono"] ?? "");
    $id_rol = intval($_POST["id_Rol"] ?? 0);
    $activo = intval($_POST["activo"] ?? 0);
    $registro = trim($_POST["fecha_registro"] ?? "");

    $stmt = $conn -> prepare("UPDATE usuarios SET 
    nombre = ?, 
    apellido = ? 
    correo = ? 
    password = ? 
    telefono = ? 
    id_rol = ? 
    activo = ? 
    registro = ? 
    WHERE id = ? ");
    $stmt -> bind_param("sssssiis", $nombre, $apellido, $correo, $password, $telefono, $id_rol, $activo, $registro);
    if($id <= 0 ||$nombre === "" || $apellido === ""){
        header("Location: usuarios/index.php?error=" . urlencode("El nombre, apellido y la contraseña son obligatorios"));
    }else{
        header("Location: usuarios/index.php?error=" . urlencode("Error al ñadir al usuario."));
    }
    $stmt -> close();
    $conn -> close();
    exit();
?>