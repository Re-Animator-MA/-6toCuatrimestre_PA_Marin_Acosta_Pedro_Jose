<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: lobros/index.php");
        exit;
    }

    $id               = intval($_POST["id"] ?? 0);
    $titulo           = trim($_POST["titulo"] ?? "");
    $isbn             = trim($_POST["isbn"] ?? "");
    $anio_publicacion = trim($_POST["anio_publicacion"] ?? "") ?: null;
    $editorial        = trim($_POST["editorial"] ?? "");
    $cantidad         = intval($_POST["cantidad"] ?? 0);
    $disponibles      = intval($_POST["disponibles"] ?? 0);
    $id_categoria     = intval($_POST["id_categoria"] ?? 0);
    $id_autores       = intval($_POST["id_autores"] ?? []);

    if ($id <= 0 || $titulo === "" || $id_categoria <= 0 || empty($id_autores)) {
        header("Location: libros/index.php?error=" . urlencode("Datos inválidos"));
        exit;
    }
    $stmt = $conn -> prepare("UPDATE libros SET 
    titulo = ?,  isbn = ?, anio_publicacion = ?, editorial = ?, cantidad = ?, disponibles = ?, id_categoria = ?, id_autores = ? WHERE id = ?");
    $stmt -> bind_param("ssssiiiii", $titulo, $isbn, $anio_publicacion, $editorial, $cantidad, $disponibles, $id_categoria, $id_autores, $id);
    if ($stmt -> execute()){
        header("Location: libros/index.php?success=" . urlencode("libro actualizado exitosamente"));
        $stmt->close();
        $conn->close();
        exit;
    }else{
        header("Location: libros/index.php?error=" .urlencode("Error al actualizar libro: " . $stmt->error));
        $stmt->close();// Cerramos la consulta preparada
        $conn->close();// Cerramos la conexión a la base de datos
        exit;
    }
    // Aquí va el código para actualizar el libro usando una consulta preparada

    // Aquí va el código para eliminar los autores actuales del libro usando una consulta preparada

    // Aquí va el código para insertar los nuevos autores en libro_autor usando una consulta preparada
?>
