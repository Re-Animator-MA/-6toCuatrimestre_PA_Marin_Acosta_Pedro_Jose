<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);

    if($id > 0){
        $stmt = $conn -> prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos WHERE id = ? ");
        $stmt -> bind_param("i", $id);
        $stmt -> execute();
        $resultado = $stmt -> get_result();
        $prestamos = $resultado -> fetch_assoc();
        $stmt -> close();
    }else{
        header("Location: prestamos/index.php?error=" . urlencode("ID inválido"));
        $conn -> close();
        exit;
    }
    ?>
    <?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-edit"></i> Editar Prestamo</h1>
    <a href="prestamos/index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<div class="card">
    <form action="prestamos/save.php">
        <input type="hidden" name="id" value="<?= $prestamos["id"] ?? $id ?>">

        <div class="form-group">
            <label><i class="fas fa-user fa-gear"></i>ID usuario</label>
            <input type="number" name="id_usuario" value="<?= htmlspecialchars($prestamos["id_usuario"] ?? "") ?>" required>
        </div>

         <div class="form-group">
            <label><i class="fas fa-calendar"></i>Fecha del prestamo</label>
            <input type="date" name="fecha_prestamo" value="<?= htmlspecialchars($prestamos["fecha_prestamo"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar"></i>Fecha de la devolución</label>
            <input type="date" name="fecha_devolucion" value="<?= htmlspecialchars($prestamos["fecha_devolucion"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-stoggle-on"></i> Estado del objeto</label>
            <select name="estado" required>
                <option value="">-- Selecciona un Rol --</option>
                <option value="prestado">Prestado</option>
                <option value="devuelto">Devuelto</option>
                <option value="retrasado">Retrasado</option>
            </select>
        </div>
    </form>

</div>
<?php include_once "../includes/footer.php"; ?>