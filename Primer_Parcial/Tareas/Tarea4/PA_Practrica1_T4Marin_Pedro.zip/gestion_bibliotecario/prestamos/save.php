<?php
require_once "../config/connection.php";
    if($_SERVER["REQUEST_METHOD"] != "POST"){
        header("Lolcation: usuarios/index.php");
        exit;
    }

    $id_usuario = intval($_POST["id_usuario"]?? 0);
    $prestamo = trim($_POST["fecha_prestamo"]?? "");
    $devolucion = trim($_POST["fecha_devolucion"]?? "");
    $estado = trim($_POST["estado"]?? "");

    if($id_usuario === ""){
        header("Location: prestamos/create.php?error=" . urlencode("El id del usuario es obligatorio"));
        exit;
    }
    $stmt = $conn -> prepare("INSERT INTO prestamos (id_usuario, fecha_prestamo, fecha_devolucion, estado) 
    VALUE(?, ?, ?, ?)");
    $stmt -> bind_param("isss", $id_usuario, $prestamo, $devolucion, $estado);

    if($stmt -> execute()){
        header("Location: prestamos/index.php?success=" . urlencode("Prestamo creado exitosamente"));
    }else{
        header("Location: prestamos/create.php?error=".urlencode("Error al crear El prestamo: " . $stmt->error));
    }
    $stmt -> close();
    $conn -> close();
    exit;