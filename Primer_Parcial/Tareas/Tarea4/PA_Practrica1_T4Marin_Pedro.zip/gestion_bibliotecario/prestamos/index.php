<?php
    require_once "../config/connection.php";
?>
<?php
    include_once "../includes/header.php";
?>