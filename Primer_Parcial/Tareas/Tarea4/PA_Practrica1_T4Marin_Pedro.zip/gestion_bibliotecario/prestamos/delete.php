<?php 
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);

    if($id <= 0){
        header("Location: prestamos/index.php?error=". urlencode("ID invalido"));
        exit;
    }

    $stmt = $conn -> prepare("DELETE FROM  prestamos WHERE id = ? ");
    $stmt -> bind_param("i", $id);
    if($stmt -> execute()){
        header("Location: prestamos/index.php?error=". urlencode("Prestamo eliminado con exito."));
    }else{
        header("Location: prestamos/index.php?error=". urlencode("Error al eliminar el prestamo."));
    }
    $stmt -> close();
    $conn -> close();
    exit();
?>