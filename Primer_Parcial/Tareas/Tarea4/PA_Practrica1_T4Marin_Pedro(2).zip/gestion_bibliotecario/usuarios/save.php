<?php 
    require_once "../config/connection.php";
    if($_SERVER["REQUEST_METHOD"] !== "POST"){
        header("Lolcation: usuarios/index.php");
        exit;
    }

    $nombre = trim($_POST["nombre"] ?? "");
    $apellido = trim($_POST["apellido"]?? "");
    $correo = trim($_POST["correo"]?? "") ?: null;
    $password = trim($_POST["password"] ?? "");
    $telefono = trim($_POST["telefono"] ?? "");
    $id_rol = intval($_POST["id_Rol"] ?? 0);
    $activo = intval($_POST["activo"] ?? 0);
    $registro = trim($_POST["fecha_registro"] ?? "");

    if($nombre === "" || $apellido === "" || $password === ""){
        header("Location: usuarios/create.php?error=" . urlencode("El nombre, apellido y la contraseña son obligatorios"));
        exit;
    }
    $stmt = $conn -> prepare("INSERT INTO usuarios (nombre, apellido, correo, password, telefono, id_rol, activo, fecha_registro) 
    VALUES(?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt -> bind_param("sssssiis", $nombre, $apellido, $correo, $password, $telefono, $id_rol, $activo, $registro);
    if($stmt -> execute()){
        header("Location: usuarios/index.php?success=" . urlencode("Usuario añadido exitosamente."));
    }else{
        header("Location: usuarios/index.php?error=" . urlencode("Error al ñadir al usuario."));
    }
    $stmt -> close();
    $conn -> close();
    exit;
?>