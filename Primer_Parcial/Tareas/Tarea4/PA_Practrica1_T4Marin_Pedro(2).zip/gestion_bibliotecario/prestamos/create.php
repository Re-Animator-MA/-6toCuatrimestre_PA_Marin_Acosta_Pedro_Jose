<?php include_once "../includes/header.php";?>

<div class="page-header">
    <h1><i class="fas fa-plus-circle"></i> Nueva Categoría</h1>
    <a href="prestamos/index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<?php if (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>

<div class="card">
    <form action="prestamos/save.php" method="POST">
        <div class="form-group">
            <label><i class="fas fa-user fa-gear"></i>ID usuario</label>
            <input type="number" name="id_usuario"  required>
        </div>

         <div class="form-group">
            <label><i class="fas fa-calendar"></i>Fecha del prestamo</label>
            <input type="date" name="fecha_prestamo" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar"></i>Fecha de la devolución</label>
            <input type="date" name="fecha_devolucion" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-stoggle-on"></i> Estado del objeto</label>
            <select name="estado" required>
                <option value="">-- Selecciona un Rol --</option>
                <option value="prestado">Prestado</option>
                <option value="devuelto">Devuelto</option>
                <option value="retrasado">Retrasado</option>
            </select>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Guardar
            </button>
            <a href="prestamos/index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>