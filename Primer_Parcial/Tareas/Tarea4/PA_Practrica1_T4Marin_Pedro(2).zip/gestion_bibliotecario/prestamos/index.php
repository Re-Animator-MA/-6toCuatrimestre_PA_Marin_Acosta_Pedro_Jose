<?php
    require_once "../config/connection.php";
?>
<?php
    include_once "../includes/header.php";
?>
<div class="page-header">
    <h1><i class = "fas fa-users"></i> Prestamos</h1>
    <a href = "prestamos/create.php" class="btn btn-primary">
        <i class = "fas fa-plus"></i> Nuevo prestamo
    </a>
</div>
<?php 
    if (isset($_GET["success"])): ?>
    <div class = "alert alert-success">
        <i class = "fas fa-check-circle"></i>
        <?= htmlspecialchars($_GET["success"]) ?>
    </div>
<?php 
    elseif (isset($_GET["error"])): ?>
    <div class = "alert alert-danger">
        <i class = "fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php 
endif; 
?>
<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Id_usuario</th>
                <th>Fecha del prestamos</th>
                <th>Fecha de la devolución</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                $stmt = $conn -> prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos");
                $stmt -> execute();
                $resultado = $stmt -> get_result();
                while($row = $resultado -> fetch_assoc()){
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["id_usuario"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["fecha_prestamo"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["fecha_devolucion"]) . "</td>";
                    echo "<Td>" . htmlspecialchars($row["estado"]) . "</td>";
                    echo "<td>";
                    echo "<a href='prestamos/edit.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-warning'><i class='fas fa-edit'></i> Editar</a>";
                    echo "<a href='prestamos/delete.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-danger'><i class='fas fa-trash'></i> Eliminar</a>";
                    echo "</td>";
                    echo "</tr>";
                }
                $stmt->close(); // Cerramos la consulta preparada para liberar recursos.
                $conn->close();
            ?>
        </tbody>
    </table>
</div>
<?php include_once "../includes/footer.php"; ?>