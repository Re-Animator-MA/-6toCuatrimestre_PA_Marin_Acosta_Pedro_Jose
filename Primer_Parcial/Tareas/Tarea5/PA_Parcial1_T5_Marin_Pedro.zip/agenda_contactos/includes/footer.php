            <footer>
                <p>&copy; <?= date("Y") ?> Agenda Contactos &dash; Administracion de contactos</p>
            </footer>
        </div>
    </body>
</html>