<!DOCTYPE html>
<html lang="es">
<head>
    <base href="/agenda_contactos/">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda Contactos</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="./assets/css/estilo.css">
</head>
<body>
    <aside class="sidebar">
        <div class="sidebar-header">
            <h2><i class="fas fa-book-open"> Agenda</i></h2>
            <p>Gestion de contactos</p>
        </div>
        <nav class="sidebar-nav">
            <a href="contactos/index.php"><i class="fas fa-book"></i>Contactos</a>

        </nav>

    </aside>
    <div class="main-content">
