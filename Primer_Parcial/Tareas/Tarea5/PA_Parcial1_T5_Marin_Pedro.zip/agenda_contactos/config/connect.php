<?php
require_once __DIR__. "/conf.php";
$conn = new mysqli($db_host, $db_user, $db_pw, $db_name);
if($conn -> connect_error){
    die("Conection failed: " . $conn -> connect_error);
}
$conn -> set_charset("utf8");
?>