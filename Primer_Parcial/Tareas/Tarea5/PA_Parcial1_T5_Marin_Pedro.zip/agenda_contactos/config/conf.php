<?php 
    $db_host = "localhost";
    $db_user = "general";
    $db_pw = "pr1m3r#5#4r10";
    $db_name = "agenda_contactos";
?>