<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-plus-circle"></i> Nuevo Contacto</h1>
    <a href="contactos/index.php" class="btn btn-secundary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>
<div class="card">
    <form action="contactos/guardar.php" method="POST">
        <div class="form-group">
            <label><i class="fas fa-id-card"></i> Nombre</label>
            <input type="text" name="nombre" required>
        </div>
        
        <div class="form-group">
            <label><i class="fas fa-id-card"></i> Apellido</label>
            <input type="text" name="apellido" >
        </div>

        <div class="form-group">
            <label><i class="fas fa-phone"></i> Telefono</label>
            <input type="text" name="telefono" required>
        </div>
        
        <div class="form-group">
            <label><i class="fas fa-envelope"></i> Correo</label>
            <input type="text" name="correo" >
        </div>

        <div class="form-group">
            <label><i class="fas fa-house"></i> Dirección</label>
            <input type="text" name="direccion" >
        </div>

        <div class="form-group">
            <label><i class="fas fa-toggle-on"></i> Categoria</label>
            <select name="categoria">
                <option value="">--Selecciona una Categoria--</option>
                <option value="Familiar">Familiar</option>
                <option value="Trabajo">Trabajo</option>
                <option value="Amigos">Amigos</option>
                <option value="General">General</option>
            </select>
        </div>
        <div class="form-group">
            <label><i class="fas fa-calendar"></i> Fecha de Registro</label>
            <input type="date" name="fecha_registro" required>
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-succes">
                <I class="fas fa-save"></I> guardar
            </button>
            <a href="contactos/index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>
<?php include_once "../includes/footer.php" ?>