<?php 
    require_once "../config/connect.php";

    if($_SERVER["REQUEST_METHOD"] !== "POST"){
        header("Location: index.php");
        exit();
    }

    $nombre = trim($_POST["nombre"]?? "");
    $apellido = trim($_POST["apellido"]?? "");
    $telefono = trim($_POST["telefono"]?? "");
    $correo = trim($_POST["correo"]?? "");
    $direccion = trim($_POST["direccion"]?? "");
    $categoria = trim($_POST["categoria"]?? "");
    $registro = trim($_POST["fecha_registro"]?? "");

    if($nombre == "" || $telefono == ""){
        header("Location: contactos/crear.php?error=". urlencode("El nombre y telefono son obligatorios"));
        exit();
    }
    $stmt = $conn -> prepare("INSERT INTO contactos (nombre, apellido, telefono, correo, direccion, categoria, fecha_registro) 
    VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt -> bind_param("sssssss", $nombre, $apellido, $telefono, $correo, $direccion, $categoria, $registro);

    if($stmt -> execute()){
        header("Location: index.php?success=". urlencode("contacto guardado"));
        $stmt -> close();
        $conn -> close();
        exit;
    }else{
        header("Location: index.php?error=". urlencode("Error al guardar contacto". $stmt -> error));
        $stmt -> close();
        $conn -> close();
        exit;
    }
?>