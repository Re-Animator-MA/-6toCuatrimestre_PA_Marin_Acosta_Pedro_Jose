<?php 
    require_once "../config/connect.php";

    if($_SERVER["REQUEST_METHOD"] !== "POST"){
        header("Location: index.php");
        exit();
    }
    $id = intval($_POST["id"]?? 0);
    $nombre = trim($_POST["nmombre"]?? "");
    $apellido = trim($_POST["apellido"]?? "");
    $telefono = trim($_POST["telefono"]?? "");
    $correo = trim($_POST["correo"]?: null);
    $direccion = trim($_post["direccion"]?? "");
    $categoria = trim($_POST["categoria"]?? "");
    $registro = trim($_POST["fecha_registro"]?? "");

    if($id <= 0 || $nombre == "" || $telefono == ""){
        header("Location: index.php?error=". urlencode("El nombre, apellido y telefono son obligatorios"));
        exit();
    }
    $stmt = $conn -> prepare("UPDATE contactos SET 
    nombre = ?, 
    apellido = ?, 
    telefono = ?, 
    correo = ?, 
    direccion = ?, 
    categoria = ?, 
    fecha_registro= ? 
    WHERE id = ?");

    $stmt -> bind_param("sssssssi", $nombre, $apellido, $telefono, $correo, $direccion, $categoria, $registro, $id);

    if($stmt -> execute()){
        header("Location: index.php?success=".urlencode("contacto Actualizado"));
        $stmt -> close();
        $conn -> close();
        exit;
    }else{
        header("Location: index.php?error=". urlencode("Error al Actualizar contacto". $stmt -> error));
        $stmt -> close();
        $conn -> close();
        exit;
    }
?>