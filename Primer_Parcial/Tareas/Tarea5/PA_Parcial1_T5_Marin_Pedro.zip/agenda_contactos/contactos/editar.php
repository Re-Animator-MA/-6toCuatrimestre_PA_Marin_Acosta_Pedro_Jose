<?php 
    require_once "../config/connect.php";

    $id = intval($_GET["id"] ?? 0);

    if($id > 0){
        $stmt = $conn -> prepare("SELECT 
        id,
        nombre,
        apellido,
        telefono, 
        correo, 
        direccion, 
        categoria, 
        fecha_registro 
        FROM contactos  WHERE id = ?
        ");
        $stmt -> bind_param("i", $id);
        $stmt -> execute();
        $resultado = $stmt -> get_result();
        $contacto = $resultado -> fetch_assoc();
        $stmt -> close();
        $conn -> close();
    }else{
        header("Location: index.php?error=". urlencode("ID iválido"));
        $conn -> close();
        exit();
    }
?>
<?php include_once "../includes/header.php";?>

<div class="page-header">
    <h1><i class="fas fa-edit"></i> Editar Contacto</h1>
    <a href="contacos/index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> volver
    </a>
</div>

<div class="card">
    <form action="contactos/actualizar.php" method="POST">
        <input type="hidden" name="id" value="<?= $contacto["id"]?? $id ?>" >

        <div class="form-group">
            <label><i class="fas fa-id-card"></i> Nombre</label>
            <input type="text" name="nombre" value="<?= htmlspecialchars($contacto["nombre"]?? "" )?>" required>
        </div>
        
        <div class="form-group">
            <label><i class="fas fa-id-card"></i> Apellido</label>
            <input type="text" name="apellido"  value="<?= htmlspecialchars($contacto["apellido"]?? "") ?>">
        </div>

        <div class="form-group">
            <label><i class="fas fa-phone"></i> Telefono</label>
            <input type="text" name="telefono" <?= htmlspecialchars($contacto["telefono"]?? "") ?> required>
        </div>
        
        <div class="form-group">
            <label><i class="fas fa-envelope"></i> Correo</label>
            <input type="text" name="correo"  <?= htmlspecialchars($contacto["correo"]?? "") ?>>
        </div>

        <div class="form-group">
            <label><i class="fas fa-house"></i> Dirección</label>
            <input type="text" name="direccion" value="<?= htmlspecialchars($contacto["direccion"]?? "") ?>">
        </div>

        <div class="form-group">
            <label><i class="fas fa-toggle-on"></i> Categoria</label>
            <select name="categoria">
                <option value="">--Selecciona una Categoria--</option>
                <option value="Familiar">Familiar</option>
                <option value="Trabajo">Trabajo</option>
                <option value="Amigos">Amigos</option>
                <option value="General">General</option>
            </select>
        </div>
        <div class="form-group">
            <label><i class="fas fa-calendar"></i> Fecha de Registro</label>
            <input type="date" name="fecha_registro" value="<?= htmlspecialchars($contacto["fecha_registro"]?? "") ?>" required>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-succes">
                <I class="fas fa-save"></I> Actualizar
            </button>
            <a href="contactos/index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>
<?php include_once "../includes/footer.php";?>