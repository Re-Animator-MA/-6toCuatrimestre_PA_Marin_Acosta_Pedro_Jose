<?php 
    require_once "../config/connect.php";

    $id = intval($_GET["id"] ?? 0);

    if($id <= 0){
        header("Location: index.php?error=". urlencode("ID invalido"));
        exit;
    }
    $stmt = $conn -> prepare("DELETE FROM contactos WHERE id = ? ");
    $stmt -> bind_param("i", $id);
    if($stmt -> execute()){
        header("Location: contactos/index.php?error=". urlencode("Contacto borrado exitosamente."));
    }else{
        header("Location: index.php?error=". urlencode("Error al borrar al contacto."));
    }
    $stmt -> close();
    $conn -> close();
    exit();
?>