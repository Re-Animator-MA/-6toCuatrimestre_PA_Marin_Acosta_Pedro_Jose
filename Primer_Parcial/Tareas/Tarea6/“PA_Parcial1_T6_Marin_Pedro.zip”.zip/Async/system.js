const URL = "https://rickandmortyapi.com/api/"

async function obtener10Posts(pagina = 1){
    try{
        const resp = await fetch(`${URL}/character?page=${pagina}`);
        if(!resp.ok){
            throw new Error(resp.status);
        }
        const datos = await resp.json();

        const personajes = datos.results.slice(0, 10);
        
        const Contenedor =  document.getElementById("resultados");
        Contenedor.innerHTML  = "";

        const tabla = document.createElement("table");
        tabla.border = "1";
        tabla.style.width = "100%"
        tabla.style.borderCollapse = "collapse";


        const encabezado = document.createElement("tr");
        ["Name", "Status", "Species", "Gender"].forEach(texto => {
            const th = document.createElement("th");
            th.textContent = texto;
            th.style.textAlign = "center";
            encabezado.appendChild(th);
        })
        tabla.appendChild(encabezado);

        personajes.forEach(p => {
            const fila = document.createElement("tr");

            const celNombre = document.createElement("td");
            celNombre.textContent = p.name;
            celNombre.style.textAlign = "center";
            fila.appendChild(celNombre);

            const celEstado = document.createElement("td");
            celEstado.textContent = p.status;
            celEstado.style.textAlign = "center";
            fila.appendChild(celEstado);

            const celEspecie = document.createElement("td");
            celEspecie.textContent = p.species;
            celEspecie.style.textAlign = "center";
            fila.appendChild(celEspecie);

            const celGenero = document.createElement("td");
            celGenero.textContent = p.gender;
            celGenero.style.textAlign = "center";
            fila.appendChild(celGenero);

            tabla.appendChild(fila);
        })
        Contenedor.appendChild(tabla);

    }catch(error){
        console.error("Error al obtener los posts: ", error);
        alert("Error al obtener los posts");
    }finally{
        console.log("Ejecución de la función obtener 10 posts finalizada");
    }
}
async function obtener10Posts2(pagina = 1){
    try{
         const resp = await fetch(`${URL}/character?page=${pagina}`);
        if(!resp.ok){
            throw new Error(resp.status);
        }
        const datos = await resp.json();

        const personajes = datos.results.slice(0, 10);
        
        const Contenedor =  document.getElementById("resultados");
        Contenedor.innerHTML  = "";

         personajes.forEach(p => {
            const item = document.createElement("p");
            //const lista = document.createElement("ul");
            //item.style.width = "100%"
            //item.style.textAlign = "justify";
            item.textContent = `${p.id} - ${p.name} - ${p.status} - ${p.gender}`;
            Contenedor.appendChild(item);
        })
        
    }catch(error){
        console.error("Error al obtener los posts: ", error);
        alert("Error al obtener los posts");
    }finally{
        console.log("Ejecución de la función obtener 10 posts finalizada");
    }
}
document.getElementById("btn-get-all").addEventListener("click", ()=> {
    obtener10Posts(1);
})
document.getElementById("btn-get-one").addEventListener("click", ()=> {
    obtener10Posts2(1);
})
document.getElementById("btn-clear").addEventListener("click", () =>{
    const Contenedor =  document.getElementById("resultados");
    Contenedor.innerHTML  = "";
})