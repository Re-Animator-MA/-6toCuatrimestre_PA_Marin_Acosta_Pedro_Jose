const BASE_URL ="https://dog.ceo/api/"

//Get
document.getElementById("btn-get-all").addEventListener("click", async() => {

    fetch(BASE_URL + "breeds/list/all") 
        .then(response => {
            if(response.ok){
                return response.json();
            }else{
                throw new Error("Error en la respuesta: "+ response.status);
            }
        })
        .then(data => {
            alert("petición exitosa");
            console.log("Respuesta de la petición", data);
            const contenedor = document.getElementById("resultados");
            contenedor.innerHTML = "<h3>Listado de razas:</h3>";
            const ul = document.createElement("li");

            Object.keys(data.message).forEach(breed => {
                const li = document.createElement("li");
                li.textContent = breed;
                ul.appendChild(li);
            })
            contenedor.appendChild(ul);
        })
        .catch(error => {
            alert("Ocurrió un error al realizar la petición");
            console.error("Error en la petición:", error);
        })
    
});

document.getElementById("btn-get-one").addEventListener("click", async () => {
    fetch(BASE_URL + "breeds/image/random")
    .then(response => {
        if(response.ok){
            return response.json();
        }else{
            throw new Error("Error en la repuesta: " + response.status);
        }
    })
    .then(data => {
        alert("Petición exitosa");
        console.log("Imagen random: ", data);
        const contenedor = document.getElementById("resultados");
        contenedor.innerHTML ="<h3>Imagenes de perros random: </h3>";
        const img = document.createElement("img");
        img.src = data.message;
        img.alt = "Perro aleatorio";
        img.style.maxWidth = "250px";
        img.style.margin = "10px";
        img.style.borderRadius = "10px";

        contenedor.appendChild(img);
    })
    .catch(error => {
        alert("ocurrió un error en la petición");
        console.log("Error en la petición: ", error);
    })
});

document.getElementById("btn-clear").addEventListener("click" , async() =>{
    const contenedor = document.getElementById("resultados");
    contenedor.innerHTML ="";
})